<?php
session_start();
include_once '../../debug.php';

// Configurar o fuso horário para Brasília
date_default_timezone_set('America/Sao_Paulo');

// Verificar se o usuário está logado
if (!isset($_SESSION['user'])) {
  header('Location: ../../index.php');
  exit;
}

// Diretório para salvar as fotos de perfil
$uploadDir = "../../uploads/perfil/";
if (!file_exists($uploadDir)) {
  mkdir($uploadDir, 0777, true);
}

// Processar atualização de perfil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['atualizar_perfil'])) {
  // Obter dados do formulário
  $nome = $_POST['nome'] ?? $_SESSION['user']['nome'];
  $email = $_POST['email'] ?? '';
  $telefone = $_POST['telefone'] ?? '';
  $campus = $_POST['campus'] ?? '';
  $cidade = $_POST['cidade'] ?? '';
  $semestre = $_POST['semestre'] ?? $_SESSION['user']['semestre'];
  $senha = $_POST['senha'] ?? '';
  
  // Processar o telefone para remover a máscara e extrair apenas os números
  $telefoneNumeros = preg_replace('/[^0-9]/', '', $telefone);
  
  // Validar email
  if (!filter_var($email, FILTER_VALIDATE_EMAIL) && !empty($email)) {
      $_SESSION['erro_perfil'] = "O formato do email é inválido.";
      header('Location: perfil.php');
      exit;
  }
  
  // Processar upload de foto de perfil
  if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] === UPLOAD_ERR_OK) {
      $tempFile = $_FILES['foto_perfil']['tmp_name'];
      $fileType = strtolower(pathinfo($_FILES['foto_perfil']['name'], PATHINFO_EXTENSION));
      
      // Verificar se é uma imagem válida
      $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
      if (in_array($fileType, $allowedTypes)) {
          // Gerar nome único para o arquivo
          $newFileName = 'user_' . $_SESSION['user']['id'] . '_' . time() . '.' . $fileType;
          $targetFilePath = $uploadDir . $newFileName;
          
          // Mover o arquivo para o diretório de destino
          if (move_uploaded_file($tempFile, $targetFilePath)) {
              // Salvar o caminho da imagem na sessão
              $_SESSION['user']['foto_perfil'] = $targetFilePath;
              
              // Atualizar a foto de perfil em todas as publicações e respostas do usuário
              atualizarFotoPerfilPublicacoes($_SESSION['user']['id'], $targetFilePath);
              
              logDebug("Foto de perfil atualizada para o usuário ID: " . $_SESSION['user']['id']);
              
              // Adicionar mensagem de sucesso específica para a foto
              $_SESSION['sucesso_foto'] = "Foto de perfil atualizada com sucesso!";
          } else {
              $_SESSION['erro_perfil'] = "Erro ao fazer upload da imagem. Tente novamente.";
              logDebug("Erro ao mover arquivo de imagem para: " . $targetFilePath);
          }
      } else {
          $_SESSION['erro_perfil'] = "Formato de arquivo não permitido. Use JPG, JPEG, PNG ou GIF.";
          logDebug("Tentativa de upload de formato não permitido: " . $fileType);
      }
  }
  
  // Atualizar dados da sessão
  $_SESSION['user']['nome'] = $nome;
  
  if (!empty($email)) {
      $_SESSION['user']['email'] = $email;
  }
  
  if (!empty($telefoneNumeros)) {
      $_SESSION['user']['telefone_raw'] = $telefoneNumeros; // Guardar números puros
      $_SESSION['user']['telefone'] = $telefone; // Guardar formato com máscara
  }
  
  $_SESSION['user']['campus'] = $campus;
  $_SESSION['user']['cidade'] = $cidade;
  $_SESSION['user']['semestre'] = $semestre;
  
  if (!empty($senha)) {
      $_SESSION['user']['senha'] = $senha; // Em produção, usar password_hash()
      logDebug("Senha atualizada para o usuário ID: " . $_SESSION['user']['id']);
  }
  
  // Registrar a atualização no log
  logDebug("Perfil atualizado para o usuário ID: " . $_SESSION['user']['id'] . ", Nome: " . $nome);
  
  // Definir mensagem de sucesso
  $_SESSION['sucesso_perfil'] = "Perfil atualizado com sucesso!";
  
  // Redirecionar para evitar reenvio do formulário
  header('Location: perfil.php');
  exit;
}

// Função para atualizar a foto de perfil em todas as publicações e respostas do usuário
function atualizarFotoPerfilPublicacoes($userId, $novaFoto) {
    $publicacoesFile = '../../publicacoes.json';
    if (file_exists($publicacoesFile)) {
        $publicacoes = json_decode(file_get_contents($publicacoesFile), true) ?: [];
        $atualizou = false;
        
        foreach ($publicacoes as &$pub) {
            // Atualizar foto nas publicações
            if ($pub['usuario_id'] == $userId) {
                $pub['foto_perfil'] = $novaFoto;
                $atualizou = true;
            }
            
            // Atualizar foto nas respostas
            if (isset($pub['respostas']) && is_array($pub['respostas'])) {
                foreach ($pub['respostas'] as &$resp) {
                    if ($resp['usuario_id'] == $userId) {
                        $resp['foto_perfil'] = $novaFoto;
                        $atualizou = true;
                    }
                }
            }
        }
        
        if ($atualizou) {
            file_put_contents($publicacoesFile, json_encode($publicacoes, JSON_PRETTY_PRINT));
            logDebug("Foto de perfil atualizada em publicações e respostas para o usuário ID: " . $userId);
        }
    }
}

// Lista de campi
$campi = [
  'IFFar Campus Panambi',
  'IFFar Campus Santa Rosa',
  'IFFar Campus Santo Augusto',
  'IFFar Campus São Borja',
  'IFFar Campus Júlio de Castilhos',
  'IFFar Campus Alegrete',
  'IFFar Campus Frederico Westphalen'
];

// Lista de cidades
$cidades = [
  'Panambi',
  'Santa Rosa',
  'Santo Augusto',
  'São Borja',
  'Júlio de Castilhos',
  'Alegrete',
  'Frederico Westphalen',
  'Ijuí',
  'Cruz Alta',
  'Passo Fundo'
];

// Lista de semestres
$semestres = [
  '1º Semestre',
  '2º Semestre',
  '3º Semestre',
  '4º Semestre',
  '5º Semestre',
  '6º Semestre'
];

// Obter dados do usuário
$usuario = $_SESSION['user'];

// Formatar o telefone para exibição
$telefoneFormatado = '';
if (!empty($usuario['telefone'])) {
  $telefoneFormatado = $usuario['telefone'];
} else {
  $telefoneFormatado = "(+__ ) __ _____-____";
}

// Obter as iniciais do nome do usuário
function getIniciais($nome) {
  $partes = explode(' ', $nome);
  $iniciais = '';
  
  if (count($partes) >= 2) {
      // Pegar a primeira letra do primeiro e último nome
      $iniciais = mb_substr($partes[0], 0, 1) . mb_substr($partes[count($partes) - 1], 0, 1);
  } else {
      // Se for apenas um nome, pegar as duas primeiras letras
      $iniciais = mb_substr($nome, 0, 2);
  }
  
  return mb_strtoupper($iniciais);
}

// Obter configurações de tema do usuário
$configTema = isset($_SESSION['user']['configuracoes']['tema']) ? $_SESSION['user']['configuracoes']['tema'] : 'claro';
$configTamanhoFonte = isset($_SESSION['user']['configuracoes']['tamanho_fonte']) ? $_SESSION['user']['configuracoes']['tamanho_fonte'] : 'medio';
$configAltoContraste = isset($_SESSION['user']['configuracoes']['alto_contraste']) && $_SESSION['user']['configuracoes']['alto_contraste'];

// Verificar cookies para usuários não logados ou para garantir consistência
if (isset($_COOKIE['tema'])) {
    $configTema = $_COOKIE['tema'];
}
if (isset($_COOKIE['tamanho_fonte'])) {
    $configTamanhoFonte = $_COOKIE['tamanho_fonte'];
}
if (isset($_COOKIE['alto_contraste']) && $_COOKIE['alto_contraste'] === 'true') {
    $configAltoContraste = true;
}

// Determinar se deve usar tema escuro
$usarTemaEscuro = $configTema === 'escuro' || 
                  ($configTema === 'sistema' && isset($_COOKIE['prefere_escuro']) && $_COOKIE['prefere_escuro'] === 'true');

// Classes CSS para aplicar ao body
$bodyClasses = [];
if ($configTamanhoFonte === 'pequeno') $bodyClasses[] = 'font-small';
if ($configTamanhoFonte === 'grande') $bodyClasses[] = 'font-large';
if ($configTamanhoFonte === 'muito_grande') $bodyClasses[] = 'font-xlarge';
if ($usarTemaEscuro) $bodyClasses[] = 'dark-theme';
if ($configAltoContraste) $bodyClasses[] = 'high-contrast';

$bodyClassString = implode(' ', $bodyClasses);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Perfil - Plataforma de Dúvidas TSI</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="../../css/styles.css">
  <link rel="stylesheet" href="../../css/tema.css">
  <link rel="stylesheet" href="perfil.css">
  <script src="../../js/tema.js"></script>
</head>
<body class="<?= $bodyClassString ?>">
  <header class="bg-teal text-white py-2">
      <div class="container-fluid">
          <div class="row align-items-center">
              <div class="col-md-4">
                  <div class="d-flex align-items-center">
                      <img src="../../img/tsi-logo.png" alt="Logo TSI" class="logo me-3">
                  </div>
              </div>
              <div class="col-md-4 text-center">
                  <h1 class="mb-0">Plataforma de Dúvidas</h1>
              </div>
              <div class="col-md-4 text-end">
                  <img src="../../img/if-logo.png" alt="Logo Instituto Federal" class="logo">
              </div>
          </div>
      </div>
  </header>

  <div class="container-fluid">
      <div class="row">
          <!-- Sidebar Esquerda -->
          <div class="col-md-2 sidebar-left py-3">
              <nav>
                  <ul class="nav flex-column">
                      <li class="nav-item">
                          <a class="nav-link" href="../../index.php"><i class="fas fa-home"></i> Página Inicial</a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link active" href="perfil.php"><i class="fas fa-user"></i> Perfil</a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="#"><i class="fas fa-laptop"></i> Portal do Aluno</a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="#"><i class="fas fa-download"></i> Baixar PPC</a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="#"><i class="fas fa-info-circle"></i> Descrição do TSI</a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="#"><i class="fas fa-question-circle"></i> Dúvidas Frequentes</a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="../configuracoes/configuracoes.php"><i class="fas fa-cog"></i> Configurações</a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="#"><i class="fas fa-universal-access"></i> Acessibilidade</a>
                      </li>
                      <?php if (isset($_SESSION['user'])): ?>
                      <li class="nav-item">
                          <a class="nav-link" href="../../index.php?logout=1"><i class="fas fa-sign-out-alt"></i> Sair</a>
                      </li>
                      <?php endif; ?>
                  </ul>
              </nav>
          </div>

          <!-- Conteúdo Principal -->
          <div class="col-md-10 main-content py-3">
              <div class="row">
                  <div class="col-md-8">
                      <h2 class="mb-4">Editar Perfil</h2>
                      
                      <?php if (isset($_SESSION['sucesso_perfil'])): ?>
                      <div class="alert alert-success alert-dismissible fade show" role="alert">
                          <?= $_SESSION['sucesso_perfil'] ?>
                          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
                      </div>
                      <?php unset($_SESSION['sucesso_perfil']); ?>
                      <?php endif; ?>
                      
                      <?php if (isset($_SESSION['sucesso_foto'])): ?>
                      <div class="alert alert-success alert-dismissible fade show" role="alert">
                          <?= $_SESSION['sucesso_foto'] ?>
                          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
                      </div>
                      <?php unset($_SESSION['sucesso_foto']); ?>
                      <?php endif; ?>
                      
                      <?php if (isset($_SESSION['erro_perfil'])): ?>
                      <div class="alert alert-danger alert-dismissible fade show" role="alert">
                          <?= $_SESSION['erro_perfil'] ?>
                          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
                      </div>
                      <?php unset($_SESSION['erro_perfil']); ?>
                      <?php endif; ?>
                      
                      <form action="perfil.php" method="post" class="perfil-form" id="form-perfil" enctype="multipart/form-data">
                          <input type="hidden" name="atualizar_perfil" value="1">
                          
                          <div class="row mb-3">
                              <div class="col-md-6">
                                  <label for="nome" class="form-label">Nome Completo <span class="text-danger">*</span></label>
                                  <div class="input-group">
                                      <input type="text" class="form-control" id="nome" name="nome" value="<?= htmlspecialchars($usuario['nome'] ?? '') ?>" required>
                                      <button class="btn btn-outline-secondary edit-btn" type="button">
                                          <i class="fas fa-pen"></i>
                                      </button>
                                  </div>
                              </div>
                              
                              <div class="col-md-6">
                                  <label for="semestre" class="form-label">Atualizar Status Acadêmico <span class="text-danger">*</span></label>
                                  <select class="form-select" id="semestre" name="semestre" required>
                                      <?php if ($usuario['tipo'] === 'professor'): ?>
                                          <option value="">Professor</option>
                                      <?php else: ?>
                                          <?php foreach ($semestres as $sem): ?>
                                              <option value="<?= $sem ?>" <?= ($usuario['semestre'] === $sem) ? 'selected' : '' ?>><?= $sem ?></option>
                                          <?php endforeach; ?>
                                      <?php endif; ?>
                                  </select>
                              </div>
                          </div>
                          
                          <div class="mb-3">
                              <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                              <div class="input-group">
                                  <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($usuario['email'] ?? '') ?>" placeholder="seu.email@exemplo.com" required>
                                  <span class="input-group-text bg-success text-white">
                                      <i class="fas fa-check"></i>
                                  </span>
                              </div>
                          </div>
                          
                          <div class="mb-3">
                              <label for="telefone" class="form-label">Número <span class="text-danger">*</span></label>
                              <input type="tel" class="form-control" id="telefone" name="telefone" value="<?= htmlspecialchars($telefoneFormatado) ?>" required>
                          </div>
                          
                          <div class="row mb-3">
                              <div class="col-md-6">
                                  <label for="campus" class="form-label">Campus <span class="text-danger">*</span></label>
                                  <select class="form-select" id="campus" name="campus" required>
                                      <?php foreach ($campi as $camp): ?>
                                          <option value="<?= $camp ?>" <?= ($usuario['campus'] ?? '') === $camp ? 'selected' : '' ?>><?= $camp ?></option>
                                      <?php endforeach; ?>
                                  </select>
                              </div>
                              
                              <div class="col-md-6">
                                  <label for="cidade" class="form-label">Cidade</label>
                                  <select class="form-select" id="cidade" name="cidade">
                                      <?php foreach ($cidades as $cid): ?>
                                          <option value="<?= $cid ?>" <?= ($usuario['cidade'] ?? '') === $cid ? 'selected' : '' ?>><?= $cid ?></option>
                                      <?php endforeach; ?>
                                  </select>
                              </div>
                          </div>
                          
                          <div class="mb-4">
                              <label for="senha" class="form-label">Senha</label>
                              <div class="input-group">
                                  <input type="password" class="form-control" id="senha" name="senha" value="" placeholder="Digite sua nova senha">
                                  <button class="input-group-text" type="button" id="toggle-senha">
                                      <i class="fas fa-eye-slash" id="icone-senha"></i>
                                  </button>
                              </div>
                              <div class="form-text">Para alterar sua senha, digite a nova senha acima ou use o botão abaixo.</div>
                              <button type="button" class="btn btn-outline-danger btn-sm mt-2" id="btn-redefinir-senha">
                                  <i class="fas fa-key me-2"></i> Redefinir Senha
                              </button>
                          </div>
                          
                          <div class="d-flex gap-2">
                              <a href="../../index.php" class="btn btn-outline-secondary">Cancelar</a>
                              <button type="submit" class="btn btn-teal">Salvar</button>
                          </div>
                      </form>
                  </div>
                  
                  <div class="col-md-4 text-center">
                      <div class="profile-picture-container">
                          <form id="form-foto" action="perfil.php" method="post" enctype="multipart/form-data">
                              <input type="hidden" name="atualizar_perfil" value="1">
                              <input type="file" name="foto_perfil" id="foto_perfil" accept="image/*" style="display: none;">
                              <div class="profile-picture" id="profile-picture">
                                  <?php if (isset($usuario['foto_perfil']) && !empty($usuario['foto_perfil']) && file_exists($usuario['foto_perfil'])): ?>
                                      <img src="<?= $usuario['foto_perfil'] ?>" alt="Foto de perfil" class="img-fluid rounded-circle" id="preview-foto">
                                  <?php else: ?>
                                      <div class="avatar-default rounded-circle" id="preview-iniciais"><?= getIniciais($usuario['nome']) ?></div>
                                      <img src="/placeholder.svg" alt="Foto de perfil" class="img-fluid rounded-circle" id="preview-foto" style="display: none;">
                                  <?php endif; ?>
                                  <div class="edit-overlay">
                                      <i class="fas fa-camera"></i>
                                  </div>
                              </div>
                              <div class="mt-2" id="foto-controls" style="display: none;">
                                  <button type="button" class="btn btn-outline-secondary btn-sm me-2" id="cancelar-foto">Cancelar</button>
                                  <button type="submit" class="btn btn-teal btn-sm">Salvar Foto</button>
                              </div>
                          </form>
                      </div>
                      
                      <div class="mt-4">
                          <h5><?= htmlspecialchars($usuario['nome']) ?></h5>
                          <p class="text-muted"><?= $usuario['tipo'] === 'professor' ? 'Professor' : $usuario['semestre'] ?></p>
                          <?php if (!empty($usuario['email'])): ?>
                          <p class="text-muted small"><i class="fas fa-envelope me-2"></i><?= htmlspecialchars($usuario['email']) ?></p>
                          <?php endif; ?>
                          <?php if (!empty($usuario['telefone'])): ?>
                          <p class="text-muted small"><i class="fas fa-phone me-2"></i><?= htmlspecialchars($usuario['telefone']) ?></p>
                          <?php endif; ?>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>

  <footer class="bg-teal text-white text-center py-2">
      <p class="mb-0">© 2024 TSI. TODOS OS DIREITOS RESERVADOS.</p>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  
  <script>
      document.addEventListener('DOMContentLoaded', function() {
          // Adicionar funcionalidade para o botão de editar foto de perfil
          const profilePicture = document.getElementById('profile-picture');
          const inputFoto = document.getElementById('foto_perfil');
          const previewFoto = document.getElementById('preview-foto');
          const previewIniciais = document.getElementById('preview-iniciais');
          const fotoControls = document.getElementById('foto-controls');
          const cancelarFoto = document.getElementById('cancelar-foto');
          
          // Guardar o estado original
          const temFotoOriginal = previewFoto.style.display !== 'none';
          const imagemOriginal = previewFoto.src;
          
          if (profilePicture && inputFoto) {
              profilePicture.addEventListener('click', function() {
                  inputFoto.click();
              });
              
              inputFoto.addEventListener('change', function() {
                  if (this.files && this.files[0]) {
                      const reader = new FileReader();
                      
                      reader.onload = function(e) {
                          if (previewIniciais) {
                              previewIniciais.style.display = 'none';
                          }
                          previewFoto.style.display = 'block';
                          previewFoto.src = e.target.result;
                          fotoControls.style.display = 'block';
                      };
                      
                      reader.readAsDataURL(this.files[0]);
                  }
              });
              
              cancelarFoto.addEventListener('click', function() {
                  if (temFotoOriginal) {
                      previewFoto.src = imagemOriginal;
                      previewFoto.style.display = 'block';
                      if (previewIniciais) {
                          previewIniciais.style.display = 'none';
                      }
                  } else {
                      previewFoto.style.display = 'none';
                      if (previewIniciais) {
                          previewIniciais.style.display = 'flex';
                      }
                  }
                  inputFoto.value = '';
                  fotoControls.style.display = 'none';
              });
          }
          
          // Adicionar funcionalidade para os botões de edição
          const editButtons = document.querySelectorAll('.edit-btn');
          editButtons.forEach(button => {
              button.addEventListener('click', function() {
                  const input = this.parentElement.querySelector('input');
                  input.focus();
              });
          });
      
          // Adicionar funcionalidade para o botão de redefinir senha
          const btnRedefinirSenha = document.getElementById('btn-redefinir-senha');
          if (btnRedefinirSenha) {
              btnRedefinirSenha.addEventListener('click', function() {
                  const senhaInput = document.getElementById('senha');
                  senhaInput.value = '';
                  senhaInput.focus();
                  alert('Digite sua nova senha no campo acima.');
              });
          }
          
          // Validação do formulário antes de enviar
          const formPerfil = document.getElementById('form-perfil');
          if (formPerfil) {
              formPerfil.addEventListener('submit', function(e) {
                  const email = document.getElementById('email').value;
                  const telefone = document.getElementById('telefone').value;
                  
                  // Validar email
                  if (email && !isValidEmail(email)) {
                      alert('Por favor, insira um endereço de email válido.');
                      document.getElementById('email').focus();
                      e.preventDefault();
                      return false;
                  }
                  
                  // Validar telefone (verificar se tem pelo menos alguns números)
                  if (telefone.includes('_')) {
                      const numerosDigitados = telefone.replace(/[^0-9]/g, '').length;
                      if (numerosDigitados < 8) {
                          alert('Por favor, preencha o número de telefone corretamente (mínimo 8 dígitos).');
                          document.getElementById('telefone').focus();
                          e.preventDefault();
                          return false;
                      }
                  }
                  
                  return true;
              });
          }
          
          // Função para validar email
          function isValidEmail(email) {
              const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
              return re.test(email);
          }

          // Adicionar o novo código para o toggle de senha aqui
          const toggleSenha = document.getElementById('toggle-senha');
          const iconeSenha = document.getElementById('icone-senha');
          const senhaInput = document.getElementById('senha');
          
          if (toggleSenha && iconeSenha && senhaInput) {
              toggleSenha.addEventListener('click', function() {
                  // Alternar o tipo do input entre "password" e "text"
                  if (senhaInput.type === 'password') {
                      senhaInput.type = 'text';
                      iconeSenha.classList.remove('fa-eye-slash');
                      iconeSenha.classList.add('fa-eye');
                  } else {
                      senhaInput.type = 'password';
                      iconeSenha.classList.remove('fa-eye');
                      iconeSenha.classList.add('fa-eye-slash');
                  }
              });
          }
      });
  </script>
  
  <script>
      // Máscara para o campo de telefone
      document.addEventListener('DOMContentLoaded', function() {
          const telefoneInput = document.getElementById('telefone');
          
          if (telefoneInput) {
              // Definir o formato inicial quando o campo estiver vazio ou contiver apenas underscores
              if (!telefoneInput.value || telefoneInput.value === "(+__ ) __ _____-____") {
                  telefoneInput.value = "(+__ ) __ _____-____";
              }
              
              // Posicionar o cursor no início ao focar se o campo tiver o formato padrão
              telefoneInput.addEventListener('focus', function(e) {
                  if (this.value === "(+__ ) __ _____-____") {
                      // Posicionar o cursor após o "+"
                      setTimeout(() => {
                          this.setSelectionRange(2, 2);
                      }, 0);
                  }
              });
              
              // Processar entrada de números
              telefoneInput.addEventListener('keydown', function(e) {
                  // Permitir teclas de navegação e controle
                  if (e.key === 'Backspace' || e.key === 'Delete' || 
                      e.key === 'ArrowLeft' || e.key === 'ArrowRight' || 
                      e.key === 'Tab' || e.ctrlKey || e.metaKey) {
                      return;
                  }
                  
                  // Bloquear teclas que não são números
                  if (!/^\d$/.test(e.key)) {
                      e.preventDefault();
                      return;
                  }
                  
                  const cursorPos = this.selectionStart;
                  const valorAtual = this.value;
                  
                  // Encontrar a próxima posição para inserir um número
                  let proximaPos = cursorPos;
                  while (proximaPos < valorAtual.length && 
                         !/^_$/.test(valorAtual.charAt(proximaPos))) {
                      proximaPos++;
                  }
                  
                  // Se não houver mais posições disponíveis, bloquear a entrada
                  if (proximaPos >= valorAtual.length) {
                      e.preventDefault();
                      return;
                  }
                  
                  // Substituir o próximo underscore pelo número digitado
                  const novoValor = valorAtual.substring(0, proximaPos) + 
                                   e.key + 
                                   valorAtual.substring(proximaPos + 1);
                  
                  this.value = novoValor;
                  
                  // Posicionar o cursor após o número inserido
                  setTimeout(() => {
                      // Encontrar a próxima posição após o número inserido
                      let novaPosicao = proximaPos + 1;
                      while (novaPosicao < novoValor.length && 
                             !/^_$/.test(novoValor.charAt(novaPosicao))) {
                          novaPosicao++;
                      }
                      this.setSelectionRange(novaPosicao, novaPosicao);
                  }, 0);
                  
                  e.preventDefault();
              });
              
              // Tratar backspace para limpar números e não caracteres especiais
              telefoneInput.addEventListener('keyup', function(e) {
                  if (e.key === 'Backspace') {
                      const cursorPos = this.selectionStart;
                      const valorAtual = this.value;
                      
                      // Encontrar o número anterior ao cursor
                      let posAnterior = cursorPos - 1;
                      while (posAnterior >= 0 && !/^\d$/.test(valorAtual.charAt(posAnterior))) {
                          posAnterior--;
                      }
                      
                      // Se encontrou um número, substituí-lo por underscore
                      if (posAnterior >= 0) {
                          const novoValor = valorAtual.substring(0, posAnterior) + 
                                           '_' + 
                                           valorAtual.substring(posAnterior + 1);
                          
                          this.value = novoValor;
                          
                          // Posicionar o cursor na posição correta
                          setTimeout(() => {
                              this.setSelectionRange(posAnterior, posAnterior);
                          }, 0);
                      }
                  }
              });
          }
      });
  </script>
</body>
</html>
