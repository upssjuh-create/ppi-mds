@extends('layouts.app')

@section('content')
<!-- Área de Criação de Publicação -->
<div class="card mb-4">
    <div class="card-header bg-teal text-white">
        Criar nova Publicação
    </div>
    <div class="card-body">
        <form action="{{ route('forum.store') }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="d-flex mb-3">
                <div class="avatar-container me-3">
                    {!! Auth::user()->getImagemPerfil() !!}
                </div>
                <textarea class="form-control" name="conteudo" rows="3" placeholder="Compartilhe ideias..."></textarea>
            </div>
            <div class="d-flex justify-content-between">
                <div class="d-flex align-items-center">
                    <label class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-image"></i> Anexar imagem
                        <input type="file" name="imagem" style="display: none;" accept="image/*">
                    </label>
                </div>
                <button type="submit" class="btn btn-teal">Publicar</button>
            </div>
        </form>
    </div>
</div>

<!-- Feed de Publicações -->
@forelse ($publicacoes as $publicacao)
<div class="card mb-3 publicacao">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-start mb-3">
            <div class="d-flex">
                <div class="avatar-container me-3">
                    {!! $publicacao->user->getImagemPerfil() !!}
                </div>
                <div>
                    <h5 class="mb-0">{{ $publicacao->user->name }}</h5>
                    <p class="text-muted small mb-0">{{ $publicacao->user->semestre }}</p>
                </div>
            </div>
            <div class="text-muted small d-flex align-items-center">
                {{ $publicacao->created_at->format('d/m/Y H:i:s') }}
                
                @if (Auth::id() === $publicacao->user_id || Auth::user()->tipo === 'professor')
                <div class="dropdown ms-2">
                    <button class="btn btn-sm btn-link text-muted p-0" type="button" data-bs-toggle="dropdown">
                        <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <button class="dropdown-item" type="button" onclick="editarPublicacao({{ $publicacao->id }}, '{{ addslashes($publicacao->conteudo) }}')">
                                <i class="fas fa-edit me-2"></i>Editar
                            </button>
                        </li>
                        <li>
                            <form action="{{ route('forum.destroy', $publicacao) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button class="dropdown-item" type="submit" onclick="return confirm('Tem certeza?')">
                                    <i class="fas fa-trash-alt me-2"></i>Excluir
                                </button>
                            </form>
                        </li>
                    </ul>
                </div>
                @endif
                
                @if ($publicacao->editado)
                <span class="badge bg-secondary ms-2">Editado</span>
                @endif
            </div>
        </div>
        
        <p>{{ $publicacao->conteudo }}</p>
        
        @if ($publicacao->imagem)
        <div class="post-image">
            <img src="{{ Storage::url($publicacao->imagem) }}" alt="Imagem da publicação" class="img-fluid">
        </div>
        @endif
        
        <div class="d-flex justify-content-between align-items-center">
            <button class="btn btn-sm btn-outline-secondary" onclick="toggleFormResposta({{ $publicacao->id }})">
                <i class="fas fa-reply"></i> Responder
            </button>
            
            <button class="btn btn-sm {{ $publicacao->isLikedBy(Auth::id()) ? 'btn-primary' : 'btn-outline-primary' }}" 
                    onclick="toggleLike({{ $publicacao->id }})">
                <i class="fas fa-thumbs-up"></i> 
                <span id="likes-count-{{ $publicacao->id }}">{{ $publicacao->likesCount() }}</span>
            </button>
        </div>
        
        <!-- Formulário de Resposta -->
        <div id="form-resposta-{{ $publicacao->id }}" class="form-resposta">
            <form action="{{ route('forum.respostas.store', $publicacao) }}" method="post" enctype="multipart/form-data">
                @csrf
                <div class="d-flex mb-3">
                    <div class="avatar-container me-2">
                        {!! Auth::user()->getImagemPerfil() !!}
                    </div>
                    <textarea class="form-control" name="conteudo" rows="2" placeholder="Escreva sua resposta..."></textarea>
                </div>
                <div class="d-flex justify-content-between">
                    <label class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-image"></i> Anexar imagem
                        <input type="file" name="imagem" style="display: none;" accept="image/*">
                    </label>
                    <div>
                        <button type="button" class="btn btn-sm btn-secondary me-2" onclick="toggleFormResposta({{ $publicacao->id }})">Cancelar</button>
                        <button type="submit" class="btn btn-sm btn-teal">Responder</button>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- Respostas -->
        @if ($publicacao->respostas->count() > 0)
        <div class="respostas-container">
            <h6 class="mb-3">
                <i class="fas fa-comments me-2"></i>Respostas ({{ $publicacao->respostas->count() }})
            </h6>
            
            @foreach ($publicacao->respostas as $resposta)
            <div class="resposta">
                <div class="resposta-header">
                    <div class="d-flex">
                        <div class="avatar-container me-2">
                            {!! $resposta->user->getImagemPerfil() !!}
                        </div>
                        <div>
                            <h6 class="mb-0">{{ $resposta->user->name }}</h6>
                            <p class="text-muted small mb-0">
                                {{ $resposta->created_at->format('d/m/Y H:i:s') }}
                                @if ($resposta->editado)
                                <span class="badge bg-secondary ms-1">Editado</span>
                                @endif
                            </p>
                        </div>
                    </div>
                    
                    @if (Auth::id() === $resposta->user_id || Auth::user()->tipo === 'professor')
                    <div class="dropdown">
                        <button class="btn btn-sm btn-link text-muted p-0" type="button" data-bs-toggle="dropdown">
                            <i class="fas fa-ellipsis-v"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <form action="{{ route('forum.respostas.destroy', $resposta) }}" method="POST" class="d-inline">
                                    @csrf
                                    @method('DELETE')
                                    <button class="dropdown-item" type="submit" onclick="return confirm('Tem certeza?')">
                                        <i class="fas fa-trash-alt me-2"></i>Excluir
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </div>
                    @endif
                </div>
                
                <div class="resposta-content">
                    <p class="mb-2">{{ $resposta->conteudo }}</p>
                    
                    @if ($resposta->imagem)
                    <div class="post-image">
                        <img src="{{ Storage::url($resposta->imagem) }}" alt="Imagem da resposta" class="img-fluid">
                    </div>
                    @endif
                </div>
            </div>
            @endforeach
        </div>
        @endif
    </div>
</div>
@empty
<div class="alert alert-info">
    Ainda não há publicações. Seja o primeiro a compartilhar algo!
</div>
@endforelse
@endsection

@section('sidebar')
<div class="accordion" id="accordionSidebar">
    <div class="accordion-item">
        <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEstatisticas">
                <i class="fas fa-chart-line me-2"></i> Estatísticas do Fórum
            </button>
        </h2>
        <div id="collapseEstatisticas" class="accordion-collapse collapse">
            <div class="accordion-body">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Publicações
                        <span class="badge bg-secondary rounded-pill">{{ $publicacoes->count() }}</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Respostas
                        <span class="badge bg-secondary rounded-pill">{{ $publicacoes->sum(fn($p) => $p->respostas->count()) }}</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
function toggleFormResposta(id) {
    const form = document.getElementById(`form-resposta-${id}`);
    form.style.display = form.style.display === 'none' || form.style.display === '' ? 'block' : 'none';
}

function toggleLike(publicacaoId) {
    fetch(`/forum/${publicacaoId}/like`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
            'Content-Type': 'application/json',
        },
    })
    .then(response => response.json())
    .then(data => {
        const button = event.target.closest('button');
        const countSpan = document.getElementById(`likes-count-${publicacaoId}`);
        
        if (data.liked) {
            button.classList.remove('btn-outline-primary');
            button.classList.add('btn-primary');
        } else {
            button.classList.remove('btn-primary');
            button.classList.add('btn-outline-primary');
        }
        
        countSpan.textContent = data.likes_count;
    });
}
</script>
@endpush
