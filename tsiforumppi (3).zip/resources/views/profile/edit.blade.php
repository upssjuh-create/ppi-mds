@extends('layouts.app')

@section('content')
<div class="card">
    <div class="card-header bg-teal text-white">
        <i class="fas fa-user-edit me-2"></i>Editar Perfil
    </div>
    <div class="card-body">
        <form method="post" action="{{ route('profile.update') }}" enctype="multipart/form-data">
            @csrf
            @method('patch')

            <div class="row">
                <!-- Foto de Perfil -->
                <div class="col-md-4 text-center mb-4">
                    <div class="mb-3">
                        <div class="position-relative d-inline-block">
                            @if(Auth::user()->foto_perfil)
                                <img src="{{ Storage::url(Auth::user()->foto_perfil) }}" alt="Foto de Perfil" 
                                     class="rounded-circle" style="width: 150px; height: 150px; object-fit: cover;">
                            @else
                                <div class="rounded-circle bg-teal d-flex align-items-center justify-content-center text-white" 
                                     style="width: 150px; height: 150px; font-size: 3rem; font-weight: bold;">
                                    {{ Auth::user()->getIniciais() }}
                                </div>
                            @endif
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="foto_perfil" class="form-label">Foto de Perfil</label>
                        <input type="file" class="form-control" id="foto_perfil" name="foto_perfil" accept="image/*">
                        <div class="form-text">Formatos aceitos: JPG, PNG. Máximo: 2MB</div>
                    </div>
                </div>

                <!-- Dados Pessoais -->
                <div class="col-md-8">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="name" class="form-label">Nome Completo</label>
                            <input type="text" class="form-control" id="name" name="name" 
                                   value="{{ old('name', $user->name) }}" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label">E-mail</label>
                            <input type="email" class="form-control" id="email" name="email" 
                                   value="{{ old('email', $user->email) }}" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="tipo" class="form-label">Tipo de Usuário</label>
                            <select class="form-select" id="tipo" name="tipo" required>
                                <option value="aluno" {{ old('tipo', $user->tipo) === 'aluno' ? 'selected' : '' }}>Aluno</option>
                                <option value="professor" {{ old('tipo', $user->tipo) === 'professor' ? 'selected' : '' }}>Professor</option>
                            </select>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="semestre" class="form-label">Semestre/Período</label>
                            <input type="text" class="form-control" id="semestre" name="semestre" 
                                   value="{{ old('semestre', $user->semestre) }}" 
                                   placeholder="Ex: 3º Semestre, 2024.2">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="telefone" class="form-label">Telefone</label>
                            <input type="tel" class="form-control" id="telefone" name="telefone" 
                                   value="{{ old('telefone', $user->telefone) }}" 
                                   placeholder="(11) 99999-9999">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="campus" class="form-label">Campus</label>
                            <input type="text" class="form-control" id="campus" name="campus" 
                                   value="{{ old('campus', $user->campus) }}" 
                                   placeholder="Ex: Campus São Paulo">
                        </div>

                        <div class="col-md-12 mb-3">
                            <label for="cidade" class="form-label">Cidade</label>
                            <input type="text" class="form-control" id="cidade" name="cidade" 
                                   value="{{ old('cidade', $user->cidade) }}" 
                                   placeholder="Ex: São Paulo - SP">
                        </div>
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-between">
                <a href="{{ route('forum.index') }}" class="btn btn-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Voltar
                </a>
                <button type="submit" class="btn btn-teal">
                    <i class="fas fa-save me-1"></i>Salvar Alterações
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Seção de Exclusão de Conta -->
<div class="card mt-4">
    <div class="card-header bg-danger text-white">
        <i class="fas fa-exclamation-triangle me-2"></i>Zona de Perigo
    </div>
    <div class="card-body">
        <h5 class="text-danger">Excluir Conta</h5>
        <p class="text-muted">
            Uma vez que sua conta for excluída, todos os seus dados serão permanentemente removidos. 
            Antes de excluir sua conta, faça o download de qualquer dado ou informação que deseja manter.
        </p>
        
        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#confirmDeleteModal">
            <i class="fas fa-trash-alt me-1"></i>Excluir Conta
        </button>
    </div>
</div>

<!-- Modal de Confirmação de Exclusão -->
<div class="modal fade" id="confirmDeleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="fas fa-exclamation-triangle me-2"></i>Confirmar Exclusão
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" action="{{ route('profile.destroy') }}">
                @csrf
                @method('delete')
                
                <div class="modal-body">
                    <p class="mb-3">
                        Tem certeza de que deseja excluir sua conta? Esta ação não pode ser desfeita.
                    </p>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Confirme sua senha para continuar:</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i>Cancelar
                    </button>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-trash-alt me-1"></i>Excluir Conta
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
// Máscara para telefone
document.getElementById('telefone').addEventListener('input', function(e) {
    let value = e.target.value.replace(/\D/g, '');
    
    if (value.length <= 11) {
        if (value.length <= 10) {
            value = value.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
        } else {
            value = value.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
        }
    }
    
    e.target.value = value;
});

// Preview da foto de perfil
document.getElementById('foto_perfil').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            // Encontrar a imagem ou div de avatar atual
            const container = document.querySelector('.position-relative');
            const currentElement = container.querySelector('img, div');
            
            // Criar nova imagem
            const newImg = document.createElement('img');
            newImg.src = e.target.result;
            newImg.alt = 'Preview da Foto';
            newImg.className = 'rounded-circle';
            newImg.style.cssText = 'width: 150px; height: 150px; object-fit: cover;';
            
            // Substituir elemento atual
            container.replaceChild(newImg, currentElement);
        };
        reader.readAsDataURL(file);
    }
});
</script>
@endpush
