<?php

use App\Http\Controllers\ForumController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect()->route('forum.index');
});

Route::middleware(['auth'])->group(function () {
    // Rotas do fórum
    Route::get('/forum', [ForumController::class, 'index'])->name('forum.index');
    Route::post('/forum', [ForumController::class, 'store'])->name('forum.store');
    Route::put('/forum/{publicacao}', [ForumController::class, 'update'])->name('forum.update');
    Route::delete('/forum/{publicacao}', [ForumController::class, 'destroy'])->name('forum.destroy');
    Route::post('/forum/{publicacao}/like', [ForumController::class, 'toggleLike'])->name('forum.like');
    
    // Rotas de respostas
    Route::post('/forum/{publicacao}/respostas', [ForumController::class, 'storeResposta'])->name('forum.respostas.store');
    Route::put('/respostas/{resposta}', [ForumController::class, 'updateResposta'])->name('forum.respostas.update');
    Route::delete('/respostas/{resposta}', [ForumController::class, 'destroyResposta'])->name('forum.respostas.destroy');
    
    // Rotas do perfil
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
