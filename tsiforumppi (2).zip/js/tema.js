// Função para aplicar tema com base nas configurações do usuário
function aplicarTema() {
  // Verificar se existem configurações salvas
  const configTema = localStorage.getItem("tema") || "claro"
  const configTamanhoFonte = localStorage.getItem("tamanho_fonte") || "medio"
  const configAltoContraste = localStorage.getItem("alto_contraste") === "true"

  // Remover classes existentes
  document.body.classList.remove("font-small", "font-large", "font-xlarge", "dark-theme", "high-contrast")

  // Aplicar tamanho da fonte
  if (configTamanhoFonte === "pequeno") {
    document.body.classList.add("font-small")
  } else if (configTamanhoFonte === "grande") {
    document.body.classList.add("font-large")
  } else if (configTamanhoFonte === "muito_grande") {
    document.body.classList.add("font-xlarge")
  }

  // Aplicar tema
  if (
    configTema === "escuro" ||
    (configTema === "sistema" && window.matchMedia("(prefers-color-scheme: dark)").matches)
  ) {
    document.body.classList.add("dark-theme")
    document.cookie = "prefere_escuro=true; path=/; max-age=31536000"
  } else {
    document.cookie = "prefere_escuro=false; path=/; max-age=31536000"
  }

  // Aplicar alto contraste
  if (configAltoContraste) {
    document.body.classList.add("high-contrast")
    document.cookie = "alto_contraste=true; path=/; max-age=31536000"
  } else {
    document.cookie = "alto_contraste=false; path=/; max-age=31536000"
  }
}

// Executar quando o DOM estiver carregado
document.addEventListener("DOMContentLoaded", () => {
  // Aplicar tema
  aplicarTema()

  // Verificar mudanças na preferência do sistema
  const prefereEscuroMedia = window.matchMedia("(prefers-color-scheme: dark)")
  prefereEscuroMedia.addEventListener("change", () => {
    if (localStorage.getItem("tema") === "sistema") {
      aplicarTema()
    }
  })

  // Se estiver na página de configurações, configurar os event listeners
  if (window.location.href.includes("configuracoes.php")) {
    const tamanhoFonteSelect = document.getElementById("tamanho_fonte")
    const temaRadios = document.querySelectorAll('input[name="tema"]')
    const altoContrasteCheck = document.getElementById("alto_contraste")

    if (tamanhoFonteSelect) {
      tamanhoFonteSelect.addEventListener("change", () => {
        localStorage.setItem("tamanho_fonte", tamanhoFonteSelect.value)
        aplicarTema()
        // Salvar no servidor automaticamente
        salvarConfiguracoesTema(
          document.querySelector('input[name="tema"]:checked').value,
          tamanhoFonteSelect.value,
          altoContrasteCheck.checked,
        )
      })
    }

    if (temaRadios.length > 0) {
      temaRadios.forEach((radio) => {
        radio.addEventListener("change", () => {
          if (radio.checked) {
            localStorage.setItem("tema", radio.value)
            aplicarTema()
            // Salvar no servidor automaticamente
            salvarConfiguracoesTema(radio.value, tamanhoFonteSelect.value, altoContrasteCheck.checked)
          }
        })
      })
    }

    if (altoContrasteCheck) {
      altoContrasteCheck.addEventListener("change", () => {
        localStorage.setItem("alto_contraste", altoContrasteCheck.checked)
        aplicarTema()
        // Salvar no servidor automaticamente
        salvarConfiguracoesTema(
          document.querySelector('input[name="tema"]:checked').value,
          tamanhoFonteSelect.value,
          altoContrasteCheck.checked,
        )
      })
    }
  }
})

// Função para salvar configurações de tema no servidor
function salvarConfiguracoesTema(tema, tamanhoFonte, altoContraste) {
  // Salvar localmente
  localStorage.setItem("tema", tema)
  localStorage.setItem("tamanho_fonte", tamanhoFonte)
  localStorage.setItem("alto_contraste", altoContraste)

  // Aplicar imediatamente
  aplicarTema()

  // Enviar para o servidor para salvar na sessão
  const formData = new FormData()
  formData.append("tema", tema)
  formData.append("tamanho_fonte", tamanhoFonte)
  formData.append("alto_contraste", altoContraste)

  // Usar caminho absoluto para o arquivo PHP
  const baseUrl = window.location.origin
  const projectPath = window.location.pathname.split("/").slice(0, -2).join("/")
  const apiUrl = `${baseUrl}${projectPath}/modulos/configuracoes/aplicar_tema.php`

  fetch(apiUrl, {
    method: "POST",
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      console.log("Configurações salvas:", data)
    })
    .catch((error) => {
      console.error("Erro ao salvar configurações:", error)
    })
}
