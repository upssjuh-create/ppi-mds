<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->enum('tipo', ['aluno', 'professor'])->default('aluno')->after('email');
            $table->string('semestre')->nullable()->after('tipo');
            $table->string('telefone')->nullable()->after('semestre');
            $table->string('telefone_raw')->nullable()->after('telefone');
            $table->string('campus')->nullable()->after('telefone_raw');
            $table->string('cidade')->nullable()->after('campus');
            $table->string('foto_perfil')->nullable()->after('cidade');
            $table->json('configuracoes')->nullable()->after('foto_perfil');
        });
    }

    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn([
                'tipo', 'semestre', 'telefone', 'telefone_raw', 
                'campus', 'cidade', 'foto_perfil', 'configuracoes'
            ]);
        });
    }
};
