<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'tipo',
        'semestre',
        'telefone',
        'telefone_raw',
        'campus',
        'cidade',
        'foto_perfil',
        'configuracoes',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'configuracoes' => 'array',
    ];

    public function publicacoes()
    {
        return $this->hasMany(Publicacao::class);
    }

    public function respostas()
    {
        return $this->hasMany(Resposta::class);
    }

    public function likes()
    {
        return $this->hasMany(Like::class);
    }

    public function getIniciais()
    {
        $partes = explode(' ', $this->name);
        $iniciais = '';
        
        if (count($partes) >= 2) {
            $iniciais = mb_substr($partes[0], 0, 1) . mb_substr($partes[count($partes) - 1], 0, 1);
        } else {
            $iniciais = mb_substr($this->name, 0, 2);
        }
        
        return mb_strtoupper($iniciais);
    }

    public function getImagemPerfil()
    {
        if ($this->foto_perfil && file_exists(public_path('storage/' . $this->foto_perfil))) {
            return '<img src="' . asset('storage/' . $this->foto_perfil) . '" alt="Avatar" class="avatar">';
        } else {
            $iniciais = $this->getIniciais();
            return '<div class="avatar-default">' . $iniciais . '</div>';
        }
    }

    public function getTipoFormatado()
    {
        return $this->tipo === 'professor' ? 'Professor' : 'Aluno';
    }
}
