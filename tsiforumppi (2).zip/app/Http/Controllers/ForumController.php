<?php

namespace App\Http\Controllers;

use App\Models\Publicacao;
use App\Models\Resposta;
use App\Models\Like;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class ForumController extends Controller
{
    public function index()
    {
        $publicacoes = Publicacao::with(['user', 'respostas.user', 'likes'])
            ->orderBy('created_at', 'desc')
            ->get();

        return view('forum.index', compact('publicacoes'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'conteudo' => 'required_without:imagem|string',
            'imagem' => 'required_without:conteudo|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $publicacao = new Publicacao();
        $publicacao->user_id = Auth::id();
        $publicacao->conteudo = $request->conteudo ?? '';

        if ($request->hasFile('imagem')) {
            $path = $request->file('imagem')->store('uploads', 'public');
            $publicacao->imagem = $path;
        }

        $publicacao->save();

        return redirect()->route('forum.index')->with('success', 'Publicação criada com sucesso!');
    }

    public function update(Request $request, Publicacao $publicacao)
    {
        // Verificar se o usuário pode editar
        if (Auth::id() !== $publicacao->user_id && Auth::user()->tipo !== 'professor') {
            abort(403);
        }

        $request->validate([
            'conteudo' => 'required|string',
        ]);

        $publicacao->update([
            'conteudo' => $request->conteudo,
            'editado' => true,
        ]);

        return redirect()->route('forum.index')->with('success', 'Publicação editada com sucesso!');
    }

    public function destroy(Publicacao $publicacao)
    {
        // Verificar se o usuário pode excluir
        if (Auth::id() !== $publicacao->user_id && Auth::user()->tipo !== 'professor') {
            abort(403);
        }

        // Excluir imagem se existir
        if ($publicacao->imagem) {
            Storage::disk('public')->delete($publicacao->imagem);
        }

        $publicacao->delete();

        return redirect()->route('forum.index')->with('success', 'Publicação excluída com sucesso!');
    }

    public function toggleLike(Publicacao $publicacao)
    {
        $like = Like::where('publicacao_id', $publicacao->id)
            ->where('user_id', Auth::id())
            ->first();

        if ($like) {
            $like->delete();
            $liked = false;
        } else {
            Like::create([
                'publicacao_id' => $publicacao->id,
                'user_id' => Auth::id(),
            ]);
            $liked = true;
        }

        return response()->json([
            'liked' => $liked,
            'likes_count' => $publicacao->likesCount(),
        ]);
    }

    public function storeResposta(Request $request, Publicacao $publicacao)
    {
        $request->validate([
            'conteudo' => 'required_without:imagem|string',
            'imagem' => 'required_without:conteudo|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $resposta = new Resposta();
        $resposta->publicacao_id = $publicacao->id;
        $resposta->user_id = Auth::id();
        $resposta->conteudo = $request->conteudo ?? '';

        if ($request->hasFile('imagem')) {
            $path = $request->file('imagem')->store('uploads', 'public');
            $resposta->imagem = $path;
        }

        $resposta->save();

        return redirect()->route('forum.index')->with('success', 'Resposta adicionada com sucesso!');
    }

    public function updateResposta(Request $request, Resposta $resposta)
    {
        // Verificar se o usuário pode editar
        if (Auth::id() !== $resposta->user_id && Auth::user()->tipo !== 'professor') {
            abort(403);
        }

        $request->validate([
            'conteudo' => 'required|string',
        ]);

        $resposta->update([
            'conteudo' => $request->conteudo,
            'editado' => true,
        ]);

        return redirect()->route('forum.index')->with('success', 'Resposta editada com sucesso!');
    }

    public function destroyResposta(Resposta $resposta)
    {
        // Verificar se o usuário pode excluir
        if (Auth::id() !== $resposta->user_id && Auth::user()->tipo !== 'professor') {
            abort(403);
        }

        // Excluir imagem se existir
        if ($resposta->imagem) {
            Storage::disk('public')->delete($resposta->imagem);
        }

        $resposta->delete();

        return redirect()->route('forum.index')->with('success', 'Resposta excluída com sucesso!');
    }
}
