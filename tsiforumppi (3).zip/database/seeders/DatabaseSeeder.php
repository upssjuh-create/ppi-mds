<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Publicacao;
use App\Models\Resposta;
use App\Models\Like;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Criar usuários de exemplo
        $professor = User::create([
            'name' => 'Prof. João Silva',
            'email' => 'professor@tsi.edu.br',
            'password' => Hash::make('password'),
            'tipo' => 'professor',
            'campus' => 'Campus São Paulo',
            'cidade' => 'São Paulo - SP',
        ]);

        $aluno1 = User::create([
            'name' => 'Maria Santos',
            'email' => 'maria@aluno.tsi.edu.br',
            'password' => Hash::make('password'),
            'tipo' => 'aluno',
            'semestre' => '3º Semestre',
            'campus' => 'Campus São Paulo',
            'cidade' => 'São Paulo - SP',
        ]);

        $aluno2 = User::create([
            'name' => 'Pedro Oliveira',
            'email' => 'pedro@aluno.tsi.edu.br',
            'password' => Hash::make('password'),
            'tipo' => 'aluno',
            'semestre' => '5º Semestre',
            'campus' => 'Campus São Paulo',
            'cidade' => 'São Paulo - SP',
        ]);

        // Criar publicações de exemplo
        $pub1 = Publicacao::create([
            'user_id' => $professor->id,
            'conteudo' => 'Bem-vindos ao fórum de dúvidas do TSI! Aqui vocês podem compartilhar conhecimentos, tirar dúvidas e interagir com colegas e professores. Vamos construir uma comunidade de aprendizado colaborativo!',
        ]);

        $pub2 = Publicacao::create([
            'user_id' => $aluno1->id,
            'conteudo' => 'Alguém pode me ajudar com conceitos de POO em Java? Estou com dificuldades para entender herança e polimorfismo.',
        ]);

        $pub3 = Publicacao::create([
            'user_id' => $aluno2->id,
            'conteudo' => 'Pessoal, encontrei um tutorial muito bom sobre React.js. Vale a pena conferir para quem está estudando desenvolvimento front-end!',
        ]);

        // Criar respostas de exemplo
        Resposta::create([
            'publicacao_id' => $pub2->id,
            'user_id' => $professor->id,
            'conteudo' => 'Ótima pergunta! Herança permite que uma classe filha herde características da classe pai, enquanto polimorfismo permite que objetos de diferentes classes sejam tratados de forma uniforme. Posso explicar melhor na próxima aula!',
        ]);

        Resposta::create([
            'publicacao_id' => $pub2->id,
            'user_id' => $aluno2->id,
            'conteudo' => 'Também tive essa dúvida! O que me ajudou foi praticar com exemplos simples, como Animal -> Cachorro, Gato.',
        ]);

        Resposta::create([
            'publicacao_id' => $pub3->id,
            'user_id' => $aluno1->id,
            'conteudo' => 'Obrigada pela dica! Pode compartilhar o link?',
        ]);

        // Criar alguns likes
        Like::create(['publicacao_id' => $pub1->id, 'user_id' => $aluno1->id]);
        Like::create(['publicacao_id' => $pub1->id, 'user_id' => $aluno2->id]);
        Like::create(['publicacao_id' => $pub2->id, 'user_id' => $professor->id]);
        Like::create(['publicacao_id' => $pub3->id, 'user_id' => $professor->id]);
    }
}
