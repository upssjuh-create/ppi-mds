<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <style>
        .bg-teal { background-color: #20b2aa !important; }
        .btn-teal { 
            background-color: #20b2aa; 
            border-color: #20b2aa; 
            color: white; 
        }
        .btn-teal:hover { 
            background-color: #1a9a91; 
            border-color: #1a9a91; 
            color: white; 
        }
        .logo { height: 50px; }
        .sidebar-left { background-color: #f8f9fa; }
        .sidebar-right { background-color: #f8f9fa; }
        .avatar { 
            width: 40px; 
            height: 40px; 
            border-radius: 50%; 
            object-fit: cover; 
        }
        .avatar-default { 
            width: 40px; 
            height: 40px; 
            border-radius: 50%; 
            background-color: #6c757d; 
            color: white; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            font-weight: bold; 
        }
        .form-resposta { 
            display: none; 
            margin-top: 15px; 
            padding-top: 15px; 
            border-top: 1px solid #dee2e6; 
        }
        .respostas-container { 
            margin-top: 20px; 
            padding-top: 20px; 
            border-top: 1px solid #dee2e6; 
        }
        .resposta { 
            background-color: #f8f9fa; 
            padding: 15px; 
            border-radius: 8px; 
            margin-bottom: 15px; 
        }
        .resposta-header { 
            display: flex; 
            justify-content: space-between; 
            align-items: flex-start; 
            margin-bottom: 10px; 
        }
        .post-image img { 
            max-width: 100%; 
            height: auto; 
            border-radius: 8px; 
            margin-top: 10px; 
        }
    </style>
</head>
<body>
    <header class="bg-teal text-white py-2">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-md-4">
                    <div class="d-flex align-items-center">
                        <img src="{{ asset('img/tsi-logo.png') }}" alt="Logo TSI" class="logo me-3">
                    </div>
                </div>
                <div class="col-md-4 text-center">
                    <h1 class="mb-0">Plataforma de Dúvidas</h1>
                </div>
                <div class="col-md-4 text-end">
                    <img src="{{ asset('img/if-logo.png') }}" alt="Logo Instituto Federal" class="logo">
                </div>
            </div>
        </div>
    </header>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar Esquerda -->
            <div class="col-md-2 sidebar-left py-3">
                <nav>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="{{ route('forum.index') }}">
                                <i class="fas fa-home"></i> Página Inicial
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('profile.edit') }}">
                                <i class="fas fa-user"></i> Perfil
                            </a>
                        </li>
                        <li class="nav-item">
                            <form method="POST" action="{{ route('logout') }}" class="d-inline">
                                @csrf
                                <button type="submit" class="nav-link btn btn-link text-start p-0">
                                    <i class="fas fa-sign-out-alt"></i> Sair
                                </button>
                            </form>
                        </li>
                    </ul>
                </nav>
            </div>

            <!-- Conteúdo Principal -->
            <div class="col-md-7 main-content py-3">
                @if (session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif

                @if ($errors->any())
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul class="mb-0">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif

                @yield('content')
            </div>

            <!-- Sidebar Direita -->
            <div class="col-md-3 sidebar-right py-3">
                @yield('sidebar')
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    @stack('scripts')
</body>
</html>
