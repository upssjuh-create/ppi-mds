<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProfileUpdateRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class ProfileController extends Controller
{
    public function edit(Request $request): View
    {
        return view('profile.edit', [
            'user' => $request->user(),
        ]);
    }

    public function update(Request $request): RedirectResponse
    {
        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'lowercase', 'email', 'max:255', 'unique:users,email,' . Auth::id()],
            'tipo' => ['required', 'in:aluno,professor'],
            'semestre' => ['nullable', 'string', 'max:50'],
            'telefone' => ['nullable', 'string', 'max:20'],
            'campus' => ['nullable', 'string', 'max:100'],
            'cidade' => ['nullable', 'string', 'max:100'],
            'foto_perfil' => ['nullable', 'image', 'mimes:jpeg,png,jpg', 'max:2048'],
        ]);

        $user = Auth::user();
        
        // Atualizar dados básicos
        $user->fill($request->only(['name', 'email', 'tipo', 'semestre', 'telefone', 'campus', 'cidade']));

        // Processar upload de foto
        if ($request->hasFile('foto_perfil')) {
            // Excluir foto anterior se existir
            if ($user->foto_perfil) {
                Storage::disk('public')->delete($user->foto_perfil);
            }
            
            // Salvar nova foto
            $path = $request->file('foto_perfil')->store('uploads/perfil', 'public');
            $user->foto_perfil = $path;
        }

        // Processar telefone
        if ($request->telefone) {
            $user->telefone_raw = preg_replace('/\D/', '', $request->telefone);
        }

        if ($user->isDirty('email')) {
            $user->email_verified_at = null;
        }

        $user->save();

        return Redirect::route('profile.edit')->with('status', 'Perfil atualizado com sucesso!');
    }

    public function destroy(Request $request): RedirectResponse
    {
        $request->validateWithBag('userDeletion', [
            'password' => ['required', 'current_password'],
        ]);

        $user = $request->user();

        // Excluir foto de perfil se existir
        if ($user->foto_perfil) {
            Storage::disk('public')->delete($user->foto_perfil);
        }

        Auth::logout();

        $user->delete();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return Redirect::to('/');
    }
}
