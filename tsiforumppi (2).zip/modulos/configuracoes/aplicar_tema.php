<?php
session_start();
include_once '../../debug.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user'])) {
    echo json_encode(['success' => false, 'message' => 'Usuário não está logado']);
    exit;
}

// Verificar se os dados foram enviados
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Inicializar configurações se não existirem
    if (!isset($_SESSION['user']['configuracoes'])) {
        $_SESSION['user']['configuracoes'] = [];
    }
    
    // Obter os dados enviados
    $tema = isset($_POST['tema']) ? $_POST['tema'] : 'claro';
    $tamanhoFonte = isset($_POST['tamanho_fonte']) ? $_POST['tamanho_fonte'] : 'medio';
    $altoContraste = isset($_POST['alto_contraste']) && $_POST['alto_contraste'] === 'true';
    
    // Salvar na sessão
    $_SESSION['user']['configuracoes']['tema'] = $tema;
    $_SESSION['user']['configuracoes']['tamanho_fonte'] = $tamanhoFonte;
    $_SESSION['user']['configuracoes']['alto_contraste'] = $altoContraste;
    
    // Definir cookies para persistência entre páginas
    setcookie('tema', $tema, time() + 31536000, '/');
    setcookie('tamanho_fonte', $tamanhoFonte, time() + 31536000, '/');
    setcookie('alto_contraste', $altoContraste ? 'true' : 'false', time() + 31536000, '/');
    
    // Definir cookie para tema escuro baseado na escolha
    if ($tema === 'escuro' || ($tema === 'sistema' && isset($_COOKIE['prefere_sistema_escuro']) && $_COOKIE['prefere_sistema_escuro'] === 'true')) {
        setcookie('prefere_escuro', 'true', time() + 31536000, '/');
    } else {
        setcookie('prefere_escuro', 'false', time() + 31536000, '/');
    }
    
    // Registrar a atualização no log
    logDebug("Configurações de tema atualizadas para o usuário ID: " . $_SESSION['user']['id'] . 
             " (tema: $tema, tamanho_fonte: $tamanhoFonte, alto_contraste: " . ($altoContraste ? 'sim' : 'não') . ")");
    
    // Retornar sucesso
    echo json_encode(['success' => true, 'message' => 'Configurações salvas com sucesso']);
} else {
    echo json_encode(['success' => false, 'message' => 'Método de requisição inválido']);
}
?>
