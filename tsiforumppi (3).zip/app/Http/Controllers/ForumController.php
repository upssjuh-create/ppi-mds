<?php

namespace App\Http\Controllers;

use App\Models\Publicacao;
use App\Models\Resposta;
use App\Models\Like;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;

class ForumController extends Controller
{
    public function index()
    {
        $publicacoes = Publicacao::with(['user', 'respostas.user', 'likes'])
            ->orderBy('created_at', 'desc')
            ->get();

        $estatisticas = [
            'total_publicacoes' => Publicacao::count(),
            'total_respostas' => Resposta::count(),
            'total_usuarios' => User::count(),
            'total_likes' => Like::count(),
        ];

        return view('forum.index', compact('publicacoes', 'estatisticas'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'conteudo' => 'required_without:imagem|string|nullable|max:5000',
            'imagem' => 'required_without:conteudo|image|mimes:jpeg,png,jpg,gif|max:2048|nullable',
        ], [
            'conteudo.required_without' => 'É necessário escrever algo ou anexar uma imagem.',
            'imagem.required_without' => 'É necessário escrever algo ou anexar uma imagem.',
            'imagem.image' => 'O arquivo deve ser uma imagem.',
            'imagem.max' => 'A imagem deve ter no máximo 2MB.',
            'conteudo.max' => 'O conteúdo deve ter no máximo 5000 caracteres.',
        ]);

        $publicacao = new Publicacao();
        $publicacao->user_id = Auth::id();
        $publicacao->conteudo = $request->conteudo ?? '';

        if ($request->hasFile('imagem')) {
            $path = $request->file('imagem')->store('uploads/publicacoes', 'public');
            $publicacao->imagem = $path;
        }

        $publicacao->save();

        return redirect()->route('forum.index')->with('success', 'Publicação criada com sucesso!');
    }

    public function update(Request $request, Publicacao $publicacao)
    {
        if (Auth::id() !== $publicacao->user_id && Auth::user()->tipo !== 'professor') {
            abort(403, 'Você não tem permissão para editar esta publicação.');
        }

        $request->validate([
            'conteudo' => 'required|string|max:5000',
        ], [
            'conteudo.required' => 'O conteúdo é obrigatório.',
            'conteudo.max' => 'O conteúdo deve ter no máximo 5000 caracteres.',
        ]);

        $publicacao->update([
            'conteudo' => $request->conteudo,
            'editado' => true,
        ]);

        return redirect()->route('forum.index')->with('success', 'Publicação editada com sucesso!');
    }

    public function destroy(Publicacao $publicacao)
    {
        if (Auth::id() !== $publicacao->user_id && Auth::user()->tipo !== 'professor') {
            abort(403, 'Você não tem permissão para excluir esta publicação.');
        }

        if ($publicacao->imagem) {
            Storage::disk('public')->delete($publicacao->imagem);
        }

        $publicacao->delete();

        return redirect()->route('forum.index')->with('success', 'Publicação excluída com sucesso!');
    }

    public function toggleLike(Publicacao $publicacao)
    {
        $like = Like::where('publicacao_id', $publicacao->id)
            ->where('user_id', Auth::id())
            ->first();

        if ($like) {
            $like->delete();
            $liked = false;
        } else {
            Like::create([
                'publicacao_id' => $publicacao->id,
                'user_id' => Auth::id(),
            ]);
            $liked = true;
        }

        return response()->json([
            'liked' => $liked,
            'likes_count' => $publicacao->likesCount(),
        ]);
    }

    public function storeResposta(Request $request, Publicacao $publicacao)
    {
        $request->validate([
            'conteudo' => 'required_without:imagem|string|nullable|max:3000',
            'imagem' => 'required_without:conteudo|image|mimes:jpeg,png,jpg,gif|max:2048|nullable',
        ], [
            'conteudo.required_without' => 'É necessário escrever algo ou anexar uma imagem.',
            'imagem.required_without' => 'É necessário escrever algo ou anexar uma imagem.',
            'imagem.image' => 'O arquivo deve ser uma imagem.',
            'imagem.max' => 'A imagem deve ter no máximo 2MB.',
            'conteudo.max' => 'A resposta deve ter no máximo 3000 caracteres.',
        ]);

        $resposta = new Resposta();
        $resposta->publicacao_id = $publicacao->id;
        $resposta->user_id = Auth::id();
        $resposta->conteudo = $request->conteudo ?? '';

        if ($request->hasFile('imagem')) {
            $path = $request->file('imagem')->store('uploads/respostas', 'public');
            $resposta->imagem = $path;
        }

        $resposta->save();

        return redirect()->route('forum.index')->with('success', 'Resposta adicionada com sucesso!');
    }

    public function updateResposta(Request $request, Resposta $resposta)
    {
        if (Auth::id() !== $resposta->user_id && Auth::user()->tipo !== 'professor') {
            abort(403, 'Você não tem permissão para editar esta resposta.');
        }

        $request->validate([
            'conteudo' => 'required|string|max:3000',
        ], [
            'conteudo.required' => 'O conteúdo é obrigatório.',
            'conteudo.max' => 'A resposta deve ter no máximo 3000 caracteres.',
        ]);

        $resposta->update([
            'conteudo' => $request->conteudo,
            'editado' => true,
        ]);

        return redirect()->route('forum.index')->with('success', 'Resposta editada com sucesso!');
    }

    public function destroyResposta(Resposta $resposta)
    {
        if (Auth::id() !== $resposta->user_id && Auth::user()->tipo !== 'professor') {
            abort(403, 'Você não tem permissão para excluir esta resposta.');
        }

        if ($resposta->imagem) {
            Storage::disk('public')->delete($resposta->imagem);
        }

        $resposta->delete();

        return redirect()->route('forum.index')->with('success', 'Resposta excluída com sucesso!');
    }

    public function buscar(Request $request)
    {
        $termo = $request->get('q');
        
        if (empty($termo)) {
            return redirect()->route('forum.index');
        }

        $publicacoes = Publicacao::with(['user', 'respostas.user', 'likes'])
            ->where('conteudo', 'LIKE', "%{$termo}%")
            ->orWhereHas('user', function($query) use ($termo) {
                $query->where('name', 'LIKE', "%{$termo}%");
            })
            ->orderBy('created_at', 'desc')
            ->get();

        $estatisticas = [
            'total_publicacoes' => $publicacoes->count(),
            'total_respostas' => $publicacoes->sum(fn($p) => $p->respostas->count()),
            'termo_busca' => $termo,
        ];

        return view('forum.index', compact('publicacoes', 'estatisticas'));
    }
}
