document.addEventListener("DOMContentLoaded", () => {
  // Mostrar nome do arquivo selecionado
  const fileInput = document.querySelector('input[type="file"]')
  const fileSelected = document.getElementById("file-selected")

  if (fileInput && fileSelected) {
    fileInput.addEventListener("change", function () {
      if (this.files && this.files.length > 0) {
        fileSelected.textContent = this.files[0].name
      } else {
        fileSelected.textContent = ""
      }
    })
  }

  // Configurar o modal de edição
  const editModal = document.getElementById("editarModal")
  const bootstrap = window.bootstrap // Declare the bootstrap variable

  if (editModal) {
    // Inicializar o modal do Bootstrap
    const bsEditModal = new bootstrap.Modal(editModal)

    // Adicionar event listeners para os botões de edição
    document.querySelectorAll(".edit-post").forEach((button) => {
      button.addEventListener("click", function (e) {
        e.preventDefault()

        const id = this.getAttribute("data-id")
        const conteudo = this.getAttribute("data-conteudo")

        document.getElementById("editar_id").value = id
        document.getElementById("editar_conteudo").value = conteudo

        // Mostrar o modal
        bsEditModal.show()
      })
    })
  }

  // Inicializar tooltips do Bootstrap
  const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
  if (tooltipTriggerList.length > 0) {
    tooltipTriggerList.forEach((tooltipTriggerEl) => new bootstrap.Tooltip(tooltipTriggerEl))
  }
})

// Função para confirmar antes de excluir uma publicação
function confirmarExclusao(id) {
  if (confirm("Tem certeza que deseja excluir esta publicação?")) {
    window.location.href = `index.php?action=delete&id=${id}`
  }
}

// Função para mostrar/esconder respostas
function toggleRespostas(id) {
  const respostasContainer = document.getElementById(`respostas-${id}`)

  if (respostasContainer) {
    if (respostasContainer.style.display === "none") {
      respostasContainer.style.display = "block"
    } else {
      respostasContainer.style.display = "none"
    }
  }
}

// Função para mostrar formulário de resposta
function mostrarFormResposta(id) {
  const formResposta = document.getElementById(`form-resposta-${id}`)

  if (formResposta) {
    if (formResposta.style.display === "none") {
      formResposta.style.display = "block"
    } else {
      formResposta.style.display = "none"
    }
  }
}
