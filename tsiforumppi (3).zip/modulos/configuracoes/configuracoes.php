<?php
session_start();
include_once '../../debug.php';

// Configurar o fuso horário para Brasília
date_default_timezone_set('America/Sao_Paulo');

// Verificar se o usuário está logado
if (!isset($_SESSION['user'])) {
    header('Location: ../../index.php');
    exit;
}

// Processar atualização de configurações
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['salvar_configuracoes'])) {
    // Inicializar configurações se não existirem
    if (!isset($_SESSION['user']['configuracoes'])) {
        $_SESSION['user']['configuracoes'] = [];
    }
    
    // Configurações de notificações
    $_SESSION['user']['configuracoes']['notificacoes_email'] = isset($_POST['notificacoes_email']);
    $_SESSION['user']['configuracoes']['notificacoes_respostas'] = isset($_POST['notificacoes_respostas']);
    $_SESSION['user']['configuracoes']['notificacoes_likes'] = isset($_POST['notificacoes_likes']);
    
    // Configurações de privacidade
    $_SESSION['user']['configuracoes']['mostrar_email'] = isset($_POST['mostrar_email']);
    $_SESSION['user']['configuracoes']['mostrar_telefone'] = isset($_POST['mostrar_telefone']);
    $_SESSION['user']['configuracoes']['perfil_publico'] = isset($_POST['perfil_publico']);
    
    // Configurações de aparência
    $_SESSION['user']['configuracoes']['tema'] = $_POST['tema'] ?? 'claro';
    $_SESSION['user']['configuracoes']['tamanho_fonte'] = $_POST['tamanho_fonte'] ?? 'medio';
    
    // Configurações de acessibilidade
    $_SESSION['user']['configuracoes']['alto_contraste'] = isset($_POST['alto_contraste']);
    $_SESSION['user']['configuracoes']['reducao_movimento'] = isset($_POST['reducao_movimento']);
    $_SESSION['user']['configuracoes']['leitor_tela'] = isset($_POST['leitor_tela']);
    
    // Configurações de idioma
    $_SESSION['user']['configuracoes']['idioma'] = $_POST['idioma'] ?? 'pt-BR';
    
    // Definir cookies para persistência entre páginas
    $tema = $_POST['tema'] ?? 'claro';
    $tamanhoFonte = $_POST['tamanho_fonte'] ?? 'medio';
    $altoContraste = isset($_POST['alto_contraste']) ? 'true' : 'false';
    
    setcookie('tema', $tema, time() + 31536000, '/');
    setcookie('tamanho_fonte', $tamanhoFonte, time() + 31536000, '/');
    setcookie('alto_contraste', $altoContraste, time() + 31536000, '/');
    
    // Definir cookie para tema escuro baseado na escolha
    if ($tema === 'escuro' || ($tema === 'sistema' && isset($_COOKIE['prefere_sistema_escuro']) && $_COOKIE['prefere_sistema_escuro'] === 'true')) {
        setcookie('prefere_escuro', 'true', time() + 31536000, '/');
    } else {
        setcookie('prefere_escuro', 'false', time() + 31536000, '/');
    }
    
    // Registrar a atualização no log
    logDebug("Configurações atualizadas para o usuário ID: " . $_SESSION['user']['id']);
    
    // Definir mensagem de sucesso
    $_SESSION['sucesso_config'] = "Configurações salvas com sucesso!";
    
    // Redirecionar para evitar reenvio do formulário
    header('Location: configuracoes.php');
    exit;
}

// Garantir que todas as configurações existam
if (!isset($_SESSION['user']['configuracoes'])) {
    $_SESSION['user']['configuracoes'] = [];
}

$config = $_SESSION['user']['configuracoes'];

// Definir valores padrão para configurações que não existem
$config['notificacoes_email'] = $config['notificacoes_email'] ?? true;
$config['notificacoes_respostas'] = $config['notificacoes_respostas'] ?? true;
$config['notificacoes_likes'] = $config['notificacoes_likes'] ?? true;
$config['mostrar_email'] = $config['mostrar_email'] ?? false;
$config['mostrar_telefone'] = $config['mostrar_telefone'] ?? false;
$config['perfil_publico'] = $config['perfil_publico'] ?? true;
$config['tema'] = $config['tema'] ?? 'claro';
$config['tamanho_fonte'] = $config['tamanho_fonte'] ?? 'medio';
$config['alto_contraste'] = $config['alto_contraste'] ?? false;
$config['reducao_movimento'] = $config['reducao_movimento'] ?? false;
$config['leitor_tela'] = $config['leitor_tela'] ?? false;
$config['idioma'] = $config['idioma'] ?? 'pt-BR';

// Verificar cookies para garantir consistência
if (isset($_COOKIE['tema'])) {
    $config['tema'] = $_COOKIE['tema'];
}
if (isset($_COOKIE['tamanho_fonte'])) {
    $config['tamanho_fonte'] = $_COOKIE['tamanho_fonte'];
}
if (isset($_COOKIE['alto_contraste']) && $_COOKIE['alto_contraste'] === 'true') {
    $config['alto_contraste'] = true;
}

// Atualizar as configurações na sessão
$_SESSION['user']['configuracoes'] = $config;

// Lista de idiomas disponíveis
$idiomas = [
    'pt-BR' => 'Português (Brasil)',
    'en-US' => 'English (United States)',
    'es-ES' => 'Español'
];

// Determinar se deve usar tema escuro
$usarTemaEscuro = $config['tema'] === 'escuro' || 
                  ($config['tema'] === 'sistema' && isset($_COOKIE['prefere_escuro']) && $_COOKIE['prefere_escuro'] === 'true');

// Classes CSS para aplicar ao body
$bodyClasses = [];
if ($config['tamanho_fonte'] === 'pequeno') $bodyClasses[] = 'font-small';
if ($config['tamanho_fonte'] === 'grande') $bodyClasses[] = 'font-large';
if ($config['tamanho_fonte'] === 'muito_grande') $bodyClasses[] = 'font-xlarge';
if ($usarTemaEscuro) $bodyClasses[] = 'dark-theme';
if ($config['alto_contraste']) $bodyClasses[] = 'high-contrast';

$bodyClassString = implode(' ', $bodyClasses);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações - Plataforma de Dúvidas TSI</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../../css/styles.css">
    <link rel="stylesheet" href="../../css/tema.css">
    <link rel="stylesheet" href="configuracoes.css">
    <script src="../../js/tema.js"></script>
</head>
<body class="<?= $bodyClassString ?>">
    <header class="bg-teal text-white py-2">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-md-4">
                    <div class="d-flex align-items-center">
                        <img src="../../img/tsi-logo.png" alt="Logo TSI" class="logo me-3">
                    </div>
                </div>
                <div class="col-md-4 text-center">
                    <h1 class="mb-0">Plataforma de Dúvidas</h1>
                </div>
                <div class="col-md-4 text-end">
                    <img src="../../img/if-logo.png" alt="Logo Instituto Federal" class="logo">
                </div>
            </div>
        </div>
    </header>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar Esquerda -->
            <div class="col-md-2 sidebar-left py-3">
                <nav>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="../../index.php"><i class="fas fa-home"></i> Página Inicial</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../perfil/perfil.php"><i class="fas fa-user"></i> Perfil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="fas fa-laptop"></i> Portal do Aluno</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="fas fa-download"></i> Baixar PPC</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="fas fa-info-circle"></i> Descrição do TSI</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="fas fa-question-circle"></i> Dúvidas Frequentes</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="configuracoes.php"><i class="fas fa-cog"></i> Configurações</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="fas fa-universal-access"></i> Acessibilidade</a>
                        </li>
                        <?php if (isset($_SESSION['user'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="../../index.php?logout=1"><i class="fas fa-sign-out-alt"></i> Sair</a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>

            <!-- Conteúdo Principal -->
            <div class="col-md-10 main-content py-3">
                <div class="row">
                    <div class="col-md-8 mx-auto">
                        <h2 class="mb-4">Configurações</h2>
                        
                        <?php if (isset($_SESSION['sucesso_config'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?= $_SESSION['sucesso_config'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
                        </div>
                        <?php unset($_SESSION['sucesso_config']); ?>
                        <?php endif; ?>
                        
                        <form action="configuracoes.php" method="post" id="form-configuracoes">
                            <input type="hidden" name="salvar_configuracoes" value="1">
                            
                            <div class="card mb-4">
                                <div class="card-header bg-teal text-white">
                                    <h5 class="mb-0"><i class="fas fa-bell me-2"></i> Notificações</h5>
                                </div>
                                <div class="card-body">
                                    <div class="form-check form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" id="notificacoes_email" name="notificacoes_email" <?= $config['notificacoes_email'] ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="notificacoes_email">
                                            Receber notificações por e-mail
                                        </label>
                                        <div class="form-text">Você receberá e-mails sobre atividades importantes no fórum.</div>
                                    </div>
                                    
                                    <div class="form-check form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" id="notificacoes_respostas" name="notificacoes_respostas" <?= $config['notificacoes_respostas'] ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="notificacoes_respostas">
                                            Notificar sobre respostas às minhas publicações
                                        </label>
                                    </div>
                                    
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="notificacoes_likes" name="notificacoes_likes" <?= $config['notificacoes_likes'] ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="notificacoes_likes">
                                            Notificar sobre curtidas nas minhas publicações
                                        </label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card mb-4">
                                <div class="card-header bg-teal text-white">
                                    <h5 class="mb-0"><i class="fas fa-lock me-2"></i> Privacidade</h5>
                                </div>
                                <div class="card-body">
                                    <div class="form-check form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" id="mostrar_email" name="mostrar_email" <?= $config['mostrar_email'] ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="mostrar_email">
                                            Mostrar meu e-mail para outros usuários
                                        </label>
                                    </div>
                                    
                                    <div class="form-check form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" id="mostrar_telefone" name="mostrar_telefone" <?= $config['mostrar_telefone'] ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="mostrar_telefone">
                                            Mostrar meu telefone para outros usuários
                                        </label>
                                    </div>
                                    
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="perfil_publico" name="perfil_publico" <?= $config['perfil_publico'] ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="perfil_publico">
                                            Tornar meu perfil público
                                        </label>
                                        <div class="form-text">Se desativado, apenas usuários logados poderão ver seu perfil.</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card mb-4">
                                <div class="card-header bg-teal text-white">
                                    <h5 class="mb-0"><i class="fas fa-palette me-2"></i> Aparência</h5>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <label class="form-label">Tema</label>
                                        <div class="d-flex gap-3">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="tema" id="tema_claro" value="claro" <?= $config['tema'] === 'claro' ? 'checked' : '' ?>>
                                                <label class="form-check-label" for="tema_claro">
                                                    <i class="fas fa-sun me-1"></i> Claro
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="tema" id="tema_escuro" value="escuro" <?= $config['tema'] === 'escuro' ? 'checked' : '' ?>>
                                                <label class="form-check-label" for="tema_escuro">
                                                    <i class="fas fa-moon me-1"></i> Escuro
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="tema" id="tema_sistema" value="sistema" <?= $config['tema'] === 'sistema' ? 'checked' : '' ?>>
                                                <label class="form-check-label" for="tema_sistema">
                                                    <i class="fas fa-laptop me-1"></i> Sistema
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Tamanho da fonte</label>
                                        <select class="form-select" name="tamanho_fonte" id="tamanho_fonte">
                                            <option value="pequeno" <?= $config['tamanho_fonte'] === 'pequeno' ? 'selected' : '' ?>>Pequeno</option>
                                            <option value="medio" <?= $config['tamanho_fonte'] === 'medio' ? 'selected' : '' ?>>Médio (Padrão)</option>
                                            <option value="grande" <?= $config['tamanho_fonte'] === 'grande' ? 'selected' : '' ?>>Grande</option>
                                            <option value="muito_grande" <?= $config['tamanho_fonte'] === 'muito_grande' ? 'selected' : '' ?>>Muito Grande</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Visualização</label>
                                        <div class="preview-box p-3 border rounded" id="preview-box">
                                            <h4>Exemplo de texto</h4>
                                            <p>Este é um exemplo de como o texto será exibido com as configurações selecionadas.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card mb-4">
                                <div class="card-header bg-teal text-white">
                                    <h5 class="mb-0"><i class="fas fa-universal-access me-2"></i> Acessibilidade</h5>
                                </div>
                                <div class="card-body">
                                    <div class="form-check form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" id="alto_contraste" name="alto_contraste" <?= $config['alto_contraste'] ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="alto_contraste">
                                            Modo de alto contraste
                                        </label>
                                        <div class="form-text">Aumenta contraste entre texto e fundo para melhor legibilidade.</div>
                                    </div>
                                    
                                    <div class="form-check form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" id="reducao_movimento" name="reducao_movimento" <?= $config['reducao_movimento'] ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="reducao_movimento">
                                            Reduzir animações
                                        </label>
                                        <div class="form-text">Minimiza ou remove animações e efeitos visuais.</div>
                                    </div>
                                    
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="leitor_tela" name="leitor_tela" <?= $config['leitor_tela'] ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="leitor_tela">
                                            Otimizar para leitores de tela
                                        </label>
                                        <div class="form-text">Melhora a compatibilidade com tecnologias assistivas.</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card mb-4">
                                <div class="card-header bg-teal text-white">
                                    <h5 class="mb-0"><i class="fas fa-language me-2"></i> Idioma</h5>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <label for="idioma" class="form-label">Idioma da plataforma</label>
                                        <select class="form-select" id="idioma" name="idioma">
                                            <?php foreach ($idiomas as $codigo => $nome): ?>
                                                <option value="<?= $codigo ?>" <?= $config['idioma'] === $codigo ? 'selected' : '' ?>><?= $nome ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="form-text">O idioma selecionado será aplicado em toda a interface.</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card mb-4">
                                <div class="card-header bg-teal text-white">
                                    <h5 class="mb-0"><i class="fas fa-database me-2"></i> Dados e Conta</h5>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <button type="button" class="btn btn-outline-primary" id="btn-exportar-dados">
                                            <i class="fas fa-file-export me-2"></i> Exportar meus dados
                                        </button>
                                        <div class="form-text">Baixe uma cópia de todos os seus dados da plataforma.</div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <button type="button" class="btn btn-outline-danger" id="btn-excluir-conta">
                                            <i class="fas fa-user-times me-2"></i> Excluir minha conta
                                        </button>
                                        <div class="form-text text-danger">Esta ação é irreversível e removerá permanentemente todos os seus dados.</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="d-flex gap-2 mb-4">
                                <a href="../../index.php" class="btn btn-outline-secondary">Cancelar</a>
                                <button type="submit" class="btn btn-teal">Salvar Configurações</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="bg-teal text-white text-center py-2">
        <p class="mb-0">© 2024 TSI. TODOS OS DIREITOS RESERVADOS.</p>
    </footer>

    <!-- Modal de Confirmação de Exclusão de Conta -->
    <div class="modal fade" id="excluirContaModal" tabindex="-1" aria-labelledby="excluirContaModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="excluirContaModalLabel">Confirmar Exclusão de Conta</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <div class="modal-body">
                    <p><strong>Atenção:</strong> Você está prestes a excluir sua conta permanentemente.</p>
                    <p>Esta ação não pode ser desfeita e resultará na perda de:</p>
                    <ul>
                        <li>Todas as suas publicações e respostas</li>
                        <li>Seu perfil e configurações</li>
                        <li>Histórico de atividades</li>
                    </ul>
                    <div class="alert alert-warning">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="confirmar-exclusao">
                            <label class="form-check-label" for="confirmar-exclusao">
                                Eu entendo que esta ação é irreversível e desejo excluir minha conta.
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger" id="btn-confirmar-exclusao" disabled>Excluir Conta</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
        // Elementos do formulário
        const previewBox = document.getElementById('preview-box');
        const tamanhoFonteSelect = document.getElementById('tamanho_fonte');
        const temaRadios = document.querySelectorAll('input[name="tema"]');
        const altoContrasteCheck = document.getElementById('alto_contraste');
        const body = document.body;
        
        // Função para atualizar o preview
        function atualizarPreview() {
            // Resetar classes
            previewBox.className = 'preview-box p-3 border rounded';
            
            // Aplicar tamanho da fonte ao preview
            const tamanhoFonte = tamanhoFonteSelect.value;
            if (tamanhoFonte === 'pequeno') {
                previewBox.classList.add('font-small');
            } else if (tamanhoFonte === 'grande') {
                previewBox.classList.add('font-large');
            } else if (tamanhoFonte === 'muito_grande') {
                previewBox.classList.add('font-xlarge');
            }
            
            // Aplicar tema ao preview
            let temaAtivo = '';
            temaRadios.forEach(radio => {
                if (radio.checked) {
                    temaAtivo = radio.value;
                }
            });
            
            if (temaAtivo === 'escuro' || (temaAtivo === 'sistema' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
                previewBox.classList.add('dark-theme');
            }
            
            // Aplicar alto contraste ao preview
            if (altoContrasteCheck.checked) {
                previewBox.classList.add('high-contrast');
            }
        }
        
        // Função para aplicar configurações em tempo real à página inteira
        function aplicarConfiguracoesTempoReal() {
            // Remover classes existentes
            body.classList.remove('font-small', 'font-large', 'font-xlarge', 'dark-theme', 'high-contrast');
            
            // Aplicar tamanho da fonte
            const tamanhoFonte = tamanhoFonteSelect.value;
            if (tamanhoFonte === 'pequeno') {
                body.classList.add('font-small');
            } else if (tamanhoFonte === 'grande') {
                body.classList.add('font-large');
            } else if (tamanhoFonte === 'muito_grande') {
                body.classList.add('font-xlarge');
            }
            
            // Aplicar tema
            let temaAtivo = '';
            temaRadios.forEach(radio => {
                if (radio.checked) {
                    temaAtivo = radio.value;
                }
            });
            
            if (temaAtivo === 'escuro' || (temaAtivo === 'sistema' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
                body.classList.add('dark-theme');
                // Salvar preferência em cookie para uso no PHP
                document.cookie = "prefere_escuro=true; path=/; max-age=31536000";
            } else {
                document.cookie = "prefere_escuro=false; path=/; max-age=31536000";
            }
            
            // Aplicar alto contraste
            if (altoContrasteCheck.checked) {
                body.classList.add('high-contrast');
            }
            
            // Atualizar também o preview
            atualizarPreview();
        }
        
        // Adicionar event listeners para atualizar o preview e aplicar configurações
        tamanhoFonteSelect.addEventListener('change', function() {
            aplicarConfiguracoesTempoReal();
            // Salvar configurações automaticamente
            salvarConfiguracoesTema(
                document.querySelector('input[name="tema"]:checked').value,
                tamanhoFonteSelect.value,
                altoContrasteCheck.checked
            );
        });

        temaRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                aplicarConfiguracoesTempoReal();
                // Salvar configurações automaticamente
                salvarConfiguracoesTema(
                    radio.value,
                    tamanhoFonteSelect.value,
                    altoContrasteCheck.checked
                );
            });
        });

        altoContrasteCheck.addEventListener('change', function() {
            aplicarConfiguracoesTempoReal();
            // Salvar configurações automaticamente
            salvarConfiguracoesTema(
                document.querySelector('input[name="tema"]:checked').value,
                tamanhoFonteSelect.value,
                altoContrasteCheck.checked
            );
        });

        // Verificar preferência do sistema para o tema
        const prefereEscuroMedia = window.matchMedia('(prefers-color-scheme: dark)');
        prefereEscuroMedia.addEventListener('change', function() {
            const temaSistema = document.getElementById('tema_sistema');
            if (temaSistema && temaSistema.checked) {
                aplicarConfiguracoesTempoReal();
            }
        });
        
        // Inicializar o preview e aplicar configurações
        aplicarConfiguracoesTempoReal();
        
        // Configurar o modal de exclusão de conta
        const btnExcluirConta = document.getElementById('btn-excluir-conta');
        const confirmarExclusaoCheck = document.getElementById('confirmar-exclusao');
        const btnConfirmarExclusao = document.getElementById('btn-confirmar-exclusao');
        
        btnExcluirConta.addEventListener('click', function() {
            const excluirContaModal = new bootstrap.Modal(document.getElementById('excluirContaModal'));
            excluirContaModal.show();
        });
        
        confirmarExclusaoCheck.addEventListener('change', function() {
            btnConfirmarExclusao.disabled = !this.checked;
        });
        
        btnConfirmarExclusao.addEventListener('click', function() {
            // Aqui você implementaria a lógica para excluir a conta
            alert('Funcionalidade de exclusão de conta será implementada em breve.');
            const excluirContaModal = bootstrap.Modal.getInstance(document.getElementById('excluirContaModal'));
            excluirContaModal.hide();
        });
        
        // Configurar o botão de exportar dados
        const btnExportarDados = document.getElementById('btn-exportar-dados');
        btnExportarDados.addEventListener('click', function() {
            // Aqui você implementaria a lógica para exportar os dados
            alert('Funcionalidade de exportação de dados será implementada em breve.');
        });
    });

    // Adicionar a função salvarConfiguracoesTema
    function salvarConfiguracoesTema(tema, tamanhoFonte, altoContraste) {
        // Salvar localmente
        localStorage.setItem("tema", tema);
        localStorage.setItem("tamanho_fonte", tamanhoFonte);
        localStorage.setItem("alto_contraste", altoContraste);
        
        // Enviar para o servidor para salvar na sessão
        const formData = new FormData();
        formData.append("tema", tema);
        formData.append("tamanho_fonte", tamanhoFonte);
        formData.append("alto_contraste", altoContraste);
        
        fetch("aplicar_tema.php", {
            method: "POST",
            body: formData,
        })
        .then(response => response.json())
        .then(data => {
            console.log("Configurações salvas:", data);
            // Mostrar mensagem de sucesso
            const alertDiv = document.createElement('div');
            alertDiv.className = 'alert alert-success alert-dismissible fade show tema-alerta-fixo';
            alertDiv.setAttribute('role', 'alert');
            alertDiv.innerHTML = 'Configurações aplicadas com sucesso!<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>';
        
            // Inserir antes do formulário
            const form = document.getElementById('form-configuracoes');
            form.parentNode.insertBefore(alertDiv, form);
        
            // Remover após 3 segundos
            setTimeout(() => {
                alertDiv.remove();
            }, 3000);
        })
        .catch(error => {
            console.error("Erro ao salvar configurações:", error);
        });
    }
</script>
</body>
</html>
