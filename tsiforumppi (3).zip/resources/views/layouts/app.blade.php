<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Plataforma de Dúvidas - TSI</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --teal-color: #20b2aa;
            --teal-hover: #1a9a91;
        }
        
        .bg-teal { background-color: var(--teal-color) !important; }
        .btn-teal { 
            background-color: var(--teal-color); 
            border-color: var(--teal-color); 
            color: white; 
        }
        .btn-teal:hover { 
            background-color: var(--teal-hover); 
            border-color: var(--teal-hover); 
            color: white; 
        }
        .text-teal { color: var(--teal-color) !important; }
        
        .logo { height: 50px; }
        .sidebar-left, .sidebar-right { 
            background-color: #f8f9fa; 
            min-height: calc(100vh - 120px);
        }
        
        .avatar { 
            width: 40px; 
            height: 40px; 
            border-radius: 50%; 
            object-fit: cover; 
        }
        .avatar-default { 
            width: 40px; 
            height: 40px; 
            border-radius: 50%; 
            background: linear-gradient(135deg, var(--teal-color), var(--teal-hover)); 
            color: white; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            font-weight: bold; 
            font-size: 14px;
        }
        
        .form-resposta { 
            display: none; 
            margin-top: 15px; 
            padding-top: 15px; 
            border-top: 1px solid #dee2e6; 
        }
        .respostas-container { 
            margin-top: 20px; 
            padding-top: 20px; 
            border-top: 1px solid #dee2e6; 
        }
        .resposta { 
            background-color: #f8f9fa; 
            padding: 15px; 
            border-radius: 8px; 
            margin-bottom: 15px; 
            border-left: 3px solid var(--teal-color);
        }
        .resposta-header { 
            display: flex; 
            justify-content: space-between; 
            align-items: flex-start; 
            margin-bottom: 10px; 
        }
        .post-image img { 
            max-width: 100%; 
            height: auto; 
            border-radius: 8px; 
            margin-top: 10px; 
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .publicacao {
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .publicacao:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .nav-link {
            border-radius: 8px;
            margin-bottom: 5px;
            transition: all 0.2s ease;
        }
        .nav-link:hover {
            background-color: rgba(32, 178, 170, 0.1);
            color: var(--teal-color) !important;
        }
        .nav-link.active {
            background-color: var(--teal-color);
            color: white !important;
        }
        
        .badge-professor {
            background-color: #dc3545;
            color: white;
        }
        .badge-aluno {
            background-color: #6c757d;
            color: white;
        }
        
        .search-box {
            border-radius: 25px;
            border: 2px solid var(--teal-color);
        }
        .search-box:focus {
            box-shadow: 0 0 0 0.2rem rgba(32, 178, 170, 0.25);
            border-color: var(--teal-hover);
        }
        
        .like-button.liked {
            background-color: var(--teal-color) !important;
            border-color: var(--teal-color) !important;
        }
        
        .character-count {
            font-size: 0.8rem;
            color: #6c757d;
        }
        .character-count.warning {
            color: #ffc107;
        }
        .character-count.danger {
            color: #dc3545;
        }
    </style>
</head>
<body>
    <header class="bg-teal text-white py-3 shadow">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-md-3">
                    <div class="d-flex align-items-center">
                        <img src="{{ asset('img/tsi-logo.png') }}" alt="Logo TSI" class="logo me-3">
                        <div>
                            <h5 class="mb-0">TSI</h5>
                            <small>Tecnologia em Sistemas</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 text-center">
                    <h1 class="mb-0">Plataforma de Dúvidas</h1>
                    <small>Compartilhe conhecimento e tire suas dúvidas</small>
                </div>
                <div class="col-md-3 text-end">
                    <div class="d-flex align-items-center justify-content-end">
                        <div class="me-3">
                            <small>Bem-vindo(a),</small><br>
                            <strong>{{ Auth::user()->name }}</strong>
                            <span class="badge {{ Auth::user()->tipo === 'professor' ? 'badge-professor' : 'badge-aluno' }} ms-1">
                                {{ Auth::user()->getTipoFormatado() }}
                            </span>
                        </div>
                        <img src="{{ asset('img/if-logo.png') }}" alt="Logo Instituto Federal" class="logo">
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar Esquerda -->
            <div class="col-md-2 sidebar-left py-3">
                <nav>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('forum.index') ? 'active' : '' }}" href="{{ route('forum.index') }}">
                                <i class="fas fa-home me-2"></i>Página Inicial
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('profile.*') ? 'active' : '' }}" href="{{ route('profile.edit') }}">
                                <i class="fas fa-user me-2"></i>Meu Perfil
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="alert('Em desenvolvimento')">
                                <i class="fas fa-laptop me-2"></i>Portal do Aluno
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="alert('Em desenvolvimento')">
                                <i class="fas fa-download me-2"></i>Baixar PPC
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="alert('Em desenvolvimento')">
                                <i class="fas fa-info-circle me-2"></i>Sobre o TSI
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="alert('Em desenvolvimento')">
                                <i class="fas fa-question-circle me-2"></i>FAQ
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="alert('Em desenvolvimento')">
                                <i class="fas fa-cog me-2"></i>Configurações
                            </a>
                        </li>
                        <li class="nav-item mt-3">
                            <form method="POST" action="{{ route('logout') }}" class="d-inline">
                                @csrf
                                <button type="submit" class="nav-link btn btn-link text-start p-2 w-100 border-0" style="text-decoration: none;">
                                    <i class="fas fa-sign-out-alt me-2"></i>Sair
                                </button>
                            </form>
                        </li>
                    </ul>
                </nav>
            </div>

            <!-- Conteúdo Principal -->
            <div class="col-md-7 main-content py-3">
                @if (session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif

                @if (session('status'))
                    <div class="alert alert-info alert-dismissible fade show" role="alert">
                        <i class="fas fa-info-circle me-2"></i>{{ session('status') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif

                @if ($errors->any())
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <ul class="mb-0">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif

                @yield('content')
            </div>

            <!-- Sidebar Direita -->
            <div class="col-md-3 sidebar-right py-3">
                @yield('sidebar')
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    @stack('scripts')
</body>
</html>
