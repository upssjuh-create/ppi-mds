<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Resposta extends Model
{
    use HasFactory;

    protected $fillable = [
        'publicacao_id',
        'user_id',
        'conteudo',
        'imagem',
        'editado',
    ];

    protected $casts = [
        'editado' => 'boolean',
    ];

    public function publicacao()
    {
        return $this->belongsTo(Publicacao::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
