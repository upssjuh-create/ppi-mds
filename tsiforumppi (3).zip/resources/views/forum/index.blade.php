@extends('layouts.app')

@section('content')
<!-- Barra de Busca -->
<div class="card mb-4">
    <div class="card-body">
        <form action="{{ route('forum.buscar') }}" method="GET" class="d-flex">
            <input type="text" name="q" class="form-control search-box me-2" 
                   placeholder="Buscar publicações ou usuários..." 
                   value="{{ request('q') }}">
            <button type="submit" class="btn btn-teal">
                <i class="fas fa-search"></i>
            </button>
        </form>
        @if(request('q'))
            <div class="mt-2">
                <small class="text-muted">
                    Resultados para: <strong>"{{ request('q') }}"</strong>
                    <a href="{{ route('forum.index') }}" class="ms-2 text-teal">
                        <i class="fas fa-times"></i> Limpar busca
                    </a>
                </small>
            </div>
        @endif
    </div>
</div>

<!-- Área de Criação de Publicação -->
<div class="card mb-4">
    <div class="card-header bg-teal text-white">
        <i class="fas fa-plus-circle me-2"></i>Criar nova Publicação
    </div>
    <div class="card-body">
        <form action="{{ route('forum.store') }}" method="post" enctype="multipart/form-data" onsubmit="return validarPublicacao()">
            @csrf
            <div class="d-flex mb-3">
                <div class="avatar-container me-3">
                    {!! Auth::user()->getImagemPerfil() !!}
                </div>
                <div class="flex-grow-1">
                    <textarea class="form-control" name="conteudo" id="conteudo-publicacao" rows="3" 
                              placeholder="Compartilhe suas ideias, dúvidas ou conhecimentos..." 
                              maxlength="5000" onkeyup="contarCaracteres('conteudo-publicacao', 'contador-publicacao', 5000)"></textarea>
                    <div id="contador-publicacao" class="character-count mt-1">0/5000 caracteres</div>
                </div>
            </div>
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    <label class="btn btn-outline-secondary btn-sm me-2">
                        <i class="fas fa-image me-1"></i>Anexar imagem
                        <input type="file" name="imagem" id="imagem-publicacao" style="display: none;" accept="image/*" onchange="mostrarArquivo('imagem-publicacao', 'arquivo-selecionado')">
                    </label>
                    <span id="arquivo-selecionado" class="small text-muted"></span>
                </div>
                <button type="submit" class="btn btn-teal">
                    <i class="fas fa-paper-plane me-1"></i>Publicar
                </button>
            </div>
            <div id="erro-publicacao" class="text-danger mt-2" style="display: none;">
                <i class="fas fa-exclamation-triangle me-1"></i>Por favor, escreva algo ou anexe uma imagem antes de publicar.
            </div>
        </form>
    </div>
</div>

<!-- Feed de Publicações -->
@forelse ($publicacoes as $publicacao)
<div id="pub-{{ $publicacao->id }}" class="card mb-3 publicacao">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-start mb-3">
            <div class="d-flex">
                <div class="avatar-container me-3">
                    {!! $publicacao->user->getImagemPerfil() !!}
                </div>
                <div>
                    <h5 class="mb-0">{{ $publicacao->user->name }}</h5>
                    <div class="d-flex align-items-center">
                        <span class="badge {{ $publicacao->user->tipo === 'professor' ? 'badge-professor' : 'badge-aluno' }} me-2">
                            {{ $publicacao->user->getTipoFormatado() }}
                        </span>
                        @if($publicacao->user->semestre)
                            <small class="text-muted">{{ $publicacao->user->semestre }}</small>
                        @endif
                    </div>
                </div>
            </div>
            <div class="text-muted small d-flex align-items-center">
                <span title="{{ $publicacao->created_at->format('d/m/Y H:i:s') }}">
                    {{ $publicacao->getTempoDecorrido() }}
                </span>
                
                @if (Auth::id() === $publicacao->user_id || Auth::user()->tipo === 'professor')
                <div class="dropdown ms-2">
                    <button class="btn btn-sm btn-link text-muted p-0" type="button" data-bs-toggle="dropdown">
                        <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <button class="dropdown-item" type="button" onclick="editarPublicacao({{ $publicacao->id }}, '{{ addslashes($publicacao->conteudo) }}')">
                                <i class="fas fa-edit me-2"></i>Editar
                            </button>
                        </li>
                        <li>
                            <form action="{{ route('forum.destroy', $publicacao) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button class="dropdown-item text-danger" type="submit" onclick="return confirm('Tem certeza que deseja excluir esta publicação?')">
                                    <i class="fas fa-trash-alt me-2"></i>Excluir
                                </button>
                            </form>
                        </li>
                    </ul>
                </div>
                @endif
                
                @if ($publicacao->editado)
                <span class="badge bg-secondary ms-2" title="Esta publicação foi editada">
                    <i class="fas fa-edit me-1"></i>Editado
                </span>
                @endif
            </div>
        </div>
        
        @if($publicacao->conteudo)
            <p class="mb-2">{!! nl2br(e($publicacao->conteudo)) !!}</p>
        @endif
        
        @if ($publicacao->imagem)
        <div class="post-image">
            <img src="{{ Storage::url($publicacao->imagem) }}" alt="Imagem da publicação" class="img-fluid">
        </div>
        @endif
        
        <div class="d-flex justify-content-between align-items-center mt-3">
            <button class="btn btn-sm btn-outline-secondary" onclick="toggleFormResposta({{ $publicacao->id }})">
                <i class="fas fa-reply me-1"></i>Responder
                @if($publicacao->respostas->count() > 0)
                    ({{ $publicacao->respostas->count() }})
                @endif
            </button>
            
            <button class="btn btn-sm like-button {{ $publicacao->isLikedBy(Auth::id()) ? 'btn-primary liked' : 'btn-outline-primary' }}" 
                    onclick="toggleLike({{ $publicacao->id }})">
                <i class="fas fa-thumbs-up me-1"></i>
                <span id="likes-count-{{ $publicacao->id }}">{{ $publicacao->likesCount() }}</span>
            </button>
        </div>
        
        <!-- Formulário de Resposta -->
        <div id="form-resposta-{{ $publicacao->id }}" class="form-resposta">
            <form action="{{ route('forum.respostas.store', $publicacao) }}" method="post" enctype="multipart/form-data" onsubmit="return validarResposta({{ $publicacao->id }})">
                @csrf
                <div class="d-flex mb-3">
                    <div class="avatar-container me-2">
                        {!! Auth::user()->getImagemPerfil() !!}
                    </div>
                    <div class="flex-grow-1">
                        <textarea class="form-control" name="conteudo" id="resposta-conteudo-{{ $publicacao->id }}" rows="2" 
                                  placeholder="Escreva sua resposta..." maxlength="3000" 
                                  onkeyup="contarCaracteres('resposta-conteudo-{{ $publicacao->id }}', 'contador-resposta-{{ $publicacao->id }}', 3000)"></textarea>
                        <div id="contador-resposta-{{ $publicacao->id }}" class="character-count mt-1">0/3000 caracteres</div>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <label class="btn btn-outline-secondary btn-sm me-2">
                            <i class="fas fa-image me-1"></i>Anexar imagem
                            <input type="file" name="imagem" id="resposta-imagem-{{ $publicacao->id }}" style="display: none;" accept="image/*" 
                                   onchange="mostrarArquivo('resposta-imagem-{{ $publicacao->id }}', 'resposta-arquivo-{{ $publicacao->id }}')">
                        </label>
                        <span id="resposta-arquivo-{{ $publicacao->id }}" class="small text-muted"></span>
                    </div>
                    <div>
                        <button type="button" class="btn btn-sm btn-secondary me-2" onclick="toggleFormResposta({{ $publicacao->id }})">
                            <i class="fas fa-times me-1"></i>Cancelar
                        </button>
                        <button type="submit" class="btn btn-sm btn-teal">
                            <i class="fas fa-paper-plane me-1"></i>Responder
                        </button>
                    </div>
                </div>
                <div id="erro-resposta-{{ $publicacao->id }}" class="text-danger mt-2" style="display: none;">
                    <i class="fas fa-exclamation-triangle me-1"></i>Por favor, escreva algo ou anexe uma imagem antes de responder.
                </div>
            </form>
        </div>
        
        <!-- Respostas -->
        @if ($publicacao->respostas->count() > 0)
        <div class="respostas-container">
            <h6 class="mb-3 text-teal">
                <i class="fas fa-comments me-2"></i>Respostas ({{ $publicacao->respostas->count() }})
            </h6>
            
            @foreach ($publicacao->respostas as $resposta)
            <div class="resposta">
                <div class="resposta-header">
                    <div class="d-flex">
                        <div class="avatar-container me-2">
                            {!! $resposta->user->getImagemPerfil() !!}
                        </div>
                        <div>
                            <h6 class="mb-0">{{ $resposta->user->name }}</h6>
                            <div class="d-flex align-items-center">
                                <span class="badge {{ $resposta->user->tipo === 'professor' ? 'badge-professor' : 'badge-aluno' }} me-2">
                                    {{ $resposta->user->getTipoFormatado() }}
                                </span>
                                <small class="text-muted" title="{{ $resposta->created_at->format('d/m/Y H:i:s') }}">
                                    {{ $resposta->getTempoDecorrido() }}
                                </small>
                                @if ($resposta->editado)
                                <span class="badge bg-secondary ms-2" title="Esta resposta foi editada">
                                    <i class="fas fa-edit me-1"></i>Editado
                                </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    
                    @if (Auth::id() === $resposta->user_id || Auth::user()->tipo === 'professor')
                    <div class="dropdown">
                        <button class="btn btn-sm btn-link text-muted p-0" type="button" data-bs-toggle="dropdown">
                            <i class="fas fa-ellipsis-v"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <button class="dropdown-item" type="button" onclick="editarResposta({{ $publicacao->id }}, {{ $resposta->id }}, '{{ addslashes($resposta->conteudo) }}')">
                                    <i class="fas fa-edit me-2"></i>Editar
                                </button>
                            </li>
                            <li>
                                <form action="{{ route('forum.respostas.destroy', $resposta) }}" method="POST" class="d-inline">
                                    @csrf
                                    @method('DELETE')
                                    <button class="dropdown-item text-danger" type="submit" onclick="return confirm('Tem certeza que deseja excluir esta resposta?')">
                                        <i class="fas fa-trash-alt me-2"></i>Excluir
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </div>
                    @endif
                </div>
                
                <div class="resposta-content">
                    @if($resposta->conteudo)
                        <p class="mb-2">{!! nl2br(e($resposta->conteudo)) !!}</p>
                    @endif
                    
                    @if ($resposta->imagem)
                    <div class="post-image">
                        <img src="{{ Storage::url($resposta->imagem) }}" alt="Imagem da resposta" class="img-fluid">
                    </div>
                    @endif
                </div>
            </div>
            @endforeach
        </div>
        @endif
    </div>
</div>
@empty
<div class="alert alert-info text-center">
    <i class="fas fa-info-circle me-2"></i>
    @if(request('q'))
        Nenhuma publicação encontrada para "<strong>{{ request('q') }}</strong>".
        <br><a href="{{ route('forum.index') }}" class="text-teal">Ver todas as publicações</a>
    @else
        Ainda não há publicações. Seja o primeiro a compartilhar algo!
    @endif
</div>
@endforelse

<!-- Modais de Edição -->
<div class="modal fade" id="editarModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-teal text-white">
                <h5 class="modal-title">
                    <i class="fas fa-edit me-2"></i>Editar Publicação
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="" method="post" id="form-editar">
                @csrf
                @method('PUT')
                <div class="modal-body">
                    <textarea class="form-control" name="conteudo" id="editar_conteudo" rows="5" required maxlength="5000" 
                              onkeyup="contarCaracteres('editar_conteudo', 'contador-editar', 5000)"></textarea>
                    <div id="contador-editar" class="character-count mt-1">0/5000 caracteres</div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i>Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i>Salvar alterações
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editarRespostaModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-teal text-white">
                <h5 class="modal-title">
                    <i class="fas fa-edit me-2"></i>Editar Resposta
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="" method="post" id="form-editar-resposta">
                @csrf
                @method('PUT')
                <div class="modal-body">
                    <textarea class="form-control" name="conteudo" id="editar_resposta_conteudo" rows="5" required maxlength="3000" 
                              onkeyup="contarCaracteres('editar_resposta_conteudo', 'contador-editar-resposta', 3000)"></textarea>
                    <div id="contador-editar-resposta" class="character-count mt-1">0/3000 caracteres</div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i>Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i>Salvar alterações
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('sidebar')
<!-- Estatísticas -->
<div class="card mb-3">
    <div class="card-header bg-teal text-white">
        <i class="fas fa-chart-line me-2"></i>Estatísticas do Fórum
    </div>
    <div class="card-body">
        <div class="row text-center">
            <div class="col-6 mb-3">
                <div class="h4 text-teal mb-0">{{ $estatisticas['total_publicacoes'] ?? 0 }}</div>
                <small class="text-muted">Publicações</small>
            </div>
            <div class="col-6 mb-3">
                <div class="h4 text-teal mb-0">{{ $estatisticas['total_respostas'] ?? 0 }}</div>
                <small class="text-muted">Respostas</small>
            </div>
            <div class="col-6">
                <div class="h4 text-teal mb-0">{{ $estatisticas['total_usuarios'] ?? 0 }}</div>
                <small class="text-muted">Usuários</small>
            </div>
            <div class="col-6">
                <div class="h4 text-teal mb-0">{{ $estatisticas['total_likes'] ?? 0 }}</div>
                <small class="text-muted">Curtidas</small>
            </div>
        </div>
    </div>
</div>

<!-- Próximos Eventos -->
<div class="card mb-3">
    <div class="card-header bg-teal text-white">
        <i class="fas fa-calendar-alt me-2"></i>Próximos Eventos
    </div>
    <div class="card-body">
        <div class="list-group list-group-flush">
            <div class="list-group-item border-0 px-0">
                <strong class="text-teal">10/12 - Início das Férias</strong>
                <br><small class="text-muted">Período de recesso acadêmico</small>
            </div>
            <div class="list-group-item border-0 px-0">
                <strong class="text-teal">15/12 - Palestra: "Mercado de TI"</strong>
                <br><small class="text-muted">Auditório principal - 19h</small>
            </div>
            <div class="list-group-item border-0 px-0">
                <strong class="text-teal">20/12 - Workshop: "React.js"</strong>
                <br><small class="text-muted">Lab. Informática - 14h</small>
            </div>
        </div>
    </div>
</div>

<!-- Links Úteis -->
<div class="card">
    <div class="card-header bg-teal text-white">
        <i class="fas fa-link me-2"></i>Links Úteis
    </div>
    <div class="card-body">
        <div class="list-group list-group-flush">
            <a href="#" class="list-group-item list-group-item-action border-0 px-0" onclick="alert('Em desenvolvimento')">
                <i class="fas fa-external-link-alt me-2 text-teal"></i>Portal do Aluno
            </a>
            <a href="#" class="list-group-item list-group-item-action border-0 px-0" onclick="alert('Em desenvolvimento')">
                <i class="fas fa-book me-2 text-teal"></i>Biblioteca Digital
            </a>
            <a href="#" class="list-group-item list-group-item-action border-0 px-0" onclick="alert('Em desenvolvimento')">
                <i class="fas fa-graduation-cap me-2 text-teal"></i>Moodle
            </a>
            <a href="#" class="list-group-item list-group-item-action border-0 px-0" onclick="alert('Em desenvolvimento')">
                <i class="fas fa-envelope me-2 text-teal"></i>Webmail
            </a>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
function toggleFormResposta(id) {
    const form = document.getElementById(`form-resposta-${id}`);
    const isVisible = form.style.display === 'block';
    
    // Esconder todos os formulários de resposta
    document.querySelectorAll('.form-resposta').forEach(f => f.style.display = 'none');
    
    // Mostrar/esconder o formulário atual
    form.style.display = isVisible ? 'none' : 'block';
    
    // Focar no textarea se estiver mostrando
    if (!isVisible) {
        const textarea = form.querySelector('textarea');
        if (textarea) textarea.focus();
    }
}

function toggleLike(publicacaoId) {
    const button = event.target.closest('button');
    const originalHtml = button.innerHTML;
    
    // Mostrar loading
    button.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>...';
    button.disabled = true;
    
    fetch(`/forum/${publicacaoId}/like`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
            'Content-Type': 'application/json',
        },
    })
    .then(response => response.json())
    .then(data => {
        const countSpan = document.getElementById(`likes-count-${publicacaoId}`);
        
        if (data.liked) {
            button.classList.remove('btn-outline-primary');
            button.classList.add('btn-primary', 'liked');
        } else {
            button.classList.remove('btn-primary', 'liked');
            button.classList.add('btn-outline-primary');
        }
        
        countSpan.textContent = data.likes_count;
        button.innerHTML = `<i class="fas fa-thumbs-up me-1"></i><span id="likes-count-${publicacaoId}">${data.likes_count}</span>`;
    })
    .catch(error => {
        console.error('Erro:', error);
        button.innerHTML = originalHtml;
    })
    .finally(() => {
        button.disabled = false;
    });
}

function editarPublicacao(id, conteudo) {
    document.getElementById('editar_conteudo').value = conteudo;
    document.getElementById('form-editar').action = `/forum/${id}`;
    contarCaracteres('editar_conteudo', 'contador-editar', 5000);
    
    const modal = new bootstrap.Modal(document.getElementById('editarModal'));
    modal.show();
}

function editarResposta(pubId, respId, conteudo) {
    document.getElementById('editar_resposta_conteudo').value = conteudo;
    document.getElementById('form-editar-resposta').action = `/respostas/${respId}`;
    contarCaracteres('editar_resposta_conteudo', 'contador-editar-resposta', 3000);
    
    const modal = new bootstrap.Modal(document.getElementById('editarRespostaModal'));
    modal.show();
}

function validarPublicacao() {
    const conteudo = document.getElementById('conteudo-publicacao').value.trim();
    const imagem = document.getElementById('imagem-publicacao').files;
    const erroMsg = document.getElementById('erro-publicacao');
    
    if (conteudo === '' && (!imagem || imagem.length === 0)) {
        erroMsg.style.display = 'block';
        return false;
    }
    
    erroMsg.style.display = 'none';
    return true;
}

function validarResposta(id) {
    const conteudo = document.getElementById(`resposta-conteudo-${id}`).value.trim();
    const imagem = document.getElementById(`resposta-imagem-${id}`).files;
    const erroMsg = document.getElementById(`erro-resposta-${id}`);
    
    if (conteudo === '' && (!imagem || imagem.length === 0)) {
        erroMsg.style.display = 'block';
        return false;
    }
    
    erroMsg.style.display = 'none';
    return true;
}

function contarCaracteres(textareaId, contadorId, limite) {
    const textarea = document.getElementById(textareaId);
    const contador = document.getElementById(contadorId);
    const atual = textarea.value.length;
    
    contador.textContent = `${atual}/${limite} caracteres`;
    
    // Mudar cor baseado no limite
    contador.className = 'character-count mt-1';
    if (atual > limite * 0.9) {
        contador.classList.add('danger');
    } else if (atual > limite * 0.7) {
        contador.classList.add('warning');
    }
}

function mostrarArquivo(inputId, spanId) {
    const input = document.getElementById(inputId);
    const span = document.getElementById(spanId);
    
    if (input.files && input.files.length > 0) {
        const file = input.files[0];
        span.textContent = `📎 ${file.name}`;
        span.className = 'small text-success';
    } else {
        span.textContent = '';
    }
}

// Inicializar contadores ao carregar a página
document.addEventListener('DOMContentLoaded', function() {
    // Contador para publicação
    const pubTextarea = document.getElementById('conteudo-publicacao');
    if (pubTextarea) {
        contarCaracteres('conteudo-publicacao', 'contador-publicacao', 5000);
    }
    
    // Auto-resize para textareas
    document.querySelectorAll('textarea').forEach(textarea => {
        textarea.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = this.scrollHeight + 'px';
        });
    });
});
</script>
@endpush
